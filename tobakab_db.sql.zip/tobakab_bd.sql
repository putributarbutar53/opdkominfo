-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Des 2022 pada 12.47
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tobakab_bd`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpadmin`
--

CREATE TABLE `cpadmin` (
  `id` int(10) NOT NULL,
  `vUsername` varchar(20) DEFAULT '',
  `cPassword` varchar(32) DEFAULT '',
  `vEmail` varchar(50) DEFAULT '',
  `dLastlogin` datetime DEFAULT NULL,
  `vAuth` text,
  `vDir` text,
  `vName` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpadmin`
--

INSERT INTO `cpadmin` (`id`, `vUsername`, `cPassword`, `vEmail`, `dLastlogin`, `vAuth`, `vDir`, `vName`) VALUES
(1, 'admin', '1bbc9fad169c111dc48c5861b312f09d', 'admin@domain.com', '2022-03-14 12:58:01', 'administrator', NULL, 'Admin Utama Ok'),
(4, 'joko', '827ccb0eea8a706c4c34a16891f84e7b', 'joko@gmail.com', '2022-03-03 09:42:59', '[\"page\",\"banner\",\"filemanager\"]', '[\"page_2\",\"page_6\",\"content_9\",\"banner_1\"]', 'Joko Susilo');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpapi`
--

CREATE TABLE `cpapi` (
  `id` int(10) NOT NULL,
  `vAPI` varchar(100) DEFAULT NULL,
  `vKey` varchar(100) DEFAULT NULL,
  `dCreated` datetime DEFAULT NULL,
  `idWebsite` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpbanner`
--

CREATE TABLE `cpbanner` (
  `id` int(10) NOT NULL,
  `idCategory` int(10) DEFAULT '0',
  `vBannerName` varchar(50) DEFAULT '',
  `vBannerURL` varchar(150) DEFAULT '',
  `dCreated` date DEFAULT NULL,
  `iStatus` int(1) DEFAULT '0',
  `vFileURL` varchar(100) DEFAULT '',
  `vBannerFile` varchar(50) DEFAULT '',
  `tDetail` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpbanner`
--

INSERT INTO `cpbanner` (`id`, `idCategory`, `vBannerName`, `vBannerURL`, `dCreated`, `iStatus`, `vFileURL`, `vBannerFile`, `tDetail`) VALUES
(17, 1, 'Hello world !', '', '2022-12-05', 1, '', 'banner_20221205062419425.jpg', '<h1>Sekarang Mati Lampu Cui</h1>'),
(18, 1, 'banner', '', '2022-12-05', 1, '', 'banner_20221205062637729.png', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpbannercategory`
--

CREATE TABLE `cpbannercategory` (
  `id` int(10) NOT NULL,
  `vCategory` varchar(100) DEFAULT '',
  `vPermalink` varchar(100) DEFAULT NULL,
  `iModule` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpbannercategory`
--

INSERT INTO `cpbannercategory` (`id`, `vCategory`, `vPermalink`, `iModule`) VALUES
(1, 'INFO', 'info', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpbantuan`
--

CREATE TABLE `cpbantuan` (
  `id` int(10) NOT NULL,
  `dTanggal` date DEFAULT NULL,
  `tKet` text,
  `idSeminar` int(10) DEFAULT NULL,
  `vSumber` varchar(100) DEFAULT NULL,
  `tInclude` text,
  `iStatus` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpbantuan`
--

INSERT INTO `cpbantuan` (`id`, `dTanggal`, `tKet`, `idSeminar`, `vSumber`, `tInclude`, `iStatus`) VALUES
(1, '2022-02-02', 'Bantuan Mesin Produksi A', 0, 'APBD', NULL, 1),
(3, '2022-02-03', 'Mesin Pertanian', 1, 'APBN', NULL, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpbantuan_peserta`
--

CREATE TABLE `cpbantuan_peserta` (
  `id` int(10) NOT NULL,
  `idBantuan` int(10) DEFAULT NULL,
  `idKoperasi` int(10) DEFAULT NULL,
  `iStatus` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpbantuan_peserta`
--

INSERT INTO `cpbantuan_peserta` (`id`, `idBantuan`, `idKoperasi`, `iStatus`) VALUES
(7, 1, 4, 0),
(4, 1, 17, 0),
(6, 1, 18, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpcontent`
--

CREATE TABLE `cpcontent` (
  `id` int(10) NOT NULL,
  `idCategory` int(10) DEFAULT '0',
  `vTitle` varchar(200) DEFAULT '',
  `vPermalink` varchar(200) DEFAULT NULL,
  `dPublishDate` date DEFAULT NULL,
  `tDetail` text,
  `vGambar` varchar(40) DEFAULT '',
  `vLinkOutside` varchar(200) DEFAULT NULL,
  `vMetaTitle` varchar(100) DEFAULT NULL,
  `vMetaDesc` varchar(200) DEFAULT NULL,
  `vMetaKeyword` varchar(200) DEFAULT NULL,
  `iStatus` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpcontent`
--

INSERT INTO `cpcontent` (`id`, `idCategory`, `vTitle`, `vPermalink`, `dPublishDate`, `tDetail`, `vGambar`, `vLinkOutside`, `vMetaTitle`, `vMetaDesc`, `vMetaKeyword`, `iStatus`) VALUES
(31, 1, 'Lagi, Pemkab Toba Memberikan Bantuan Stimulan Penyediaan Rumah Swadaya Pra-Sejahtera', 'lagi-pemkab-toba-memberikan-bantuan-stimulan-penyediaan-rumah-swadaya-pra-sejahtera', '2022-10-09', '<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Pemerintah Kabupaten Toba kembali menyerahkan Bantuan Stimulan Penyediaan Rumah Swadaya Pra-Sejahtera (bedah rumah), untuk membantu masyarakat berpenghasilan rendah, membangun rumah tidak layak huni menjadi layak huni, di wilayah Kecamatan Balige.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">36 Kepala Keluarga (KK) penerima bantuan, masing-masing mendapatkan Rp. 35 juta. Buku tabungan diserahkan secara simbolis oleh Bupati Toba Poltak Sitorus, di Kantor Kelurahan Pardede Onan Balige, Kecamatan Balige, Kabupaten Toba, Provinsi Sumatra Utara,Rabu (9/11/2022).</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Menurut Bupati Poltak Sitorus, bantuan uang sebesar Rp. 35 juta tentu tidak akan cukup untuk membangun sebuah rumah layak huni. Ia meminta kepada penerima bantuan, untuk menghidupkan kembali budaya gotong-royong. Bergotong-royong dengan tetangga, bahkan menghubungi keluarga, sehingga rumah dapat diselesaikan tepat pada waktunya.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Di Kabupaten Toba terdapat sekitar 10.444 rumah yang masih tidak layak huni. Bupati Toba menyebutkan, bahwa penerima bantuan hari ini, adalah orang yang beruntung.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">&ldquo;Jadi, begitu nanti kalian tiba di rumah, langsung bersujud. (seraya mengucapkan) Tuhan, terima kasih,&rdquo; ujar Bupati Poltak Sitorus.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Menjelang ajang F1H20 24-26 Februari 2023 mendatang, Bupati Toba mengajak masyarakat agar menyambut wisatawan dengan sopan, dan tidak memberikan harga barang dagangan terlalu mahal. Karena hal ini akan membuat pembeli menjadi jera, dan besoknya tidak mau datang lagi.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Turut hadir Plt. Kadis Perumahan Rakyat dan Permukiman Tagor Siburian, Plt. Kadis Kominfo Sesmon TB Butarbutar, Camat Balige Pantun J. Pardede, Lurah Pardede Onan, dan undangan lainnya. (MC Toba)</p>', 'content_20221109111941751.jpg', '', '', '', '', 1),
(30, 1, 'Pemkab Toba Terus Perjuangankan Agar Semua Desa Masuk Listrik', 'pemkab-toba-terus-perjuangankan-agar-semua-desa-masuk-listrik', '2022-09-09', '<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Pemerintah Kabupaten Toba terus memperjuangkan semua desa di Kabupaten Toba agar masuk listrik. Untuk mewujudkan hal ini, Wakil Bupati Toba, Tonny M.Simanjuntak berkunjung dan berkoordinasi dengan Balai Besar Konservasi dan Sumber Daya Alam (BBKSDA) Provinsi Sumatra Utara (Sumut) dan Dinas Kehutanan Provinsi Sumut di Jalan Sisingamangaraja, Medan, Sumut, Rabu (9/11/2022).</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Wabup Tonny M.Simanjuntak bersama Dinas LHK Kabupaten Toba langsung diterima oleh Kepala BBKSDA Sumut, Rudianto Saragih Napitu di ruang kerjanya. Selanjutnya membahas progres perjanjian kerjasama antara BBKSDA wilayah II Sumut dan PLN serta tindak lanjut RKT III bersama Pemkab Toba terkait pemasangan aliran listrik ke Desa Sipagabu di Kecamatan Nassau dan Desa Meranti Barat di Kecamatan Pintu Pohan Meranti, Kabupaten Toba.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Terkait pemasangan listrik di dua desa ini, ada permasalahan mengenai alih fungsi kawasan hutan atau pemanfaatan kawasan hutan untuk pembangunan jaringan listrik, di mana beberapa dokumen pendukung sudah disampaikan beberapa waktu yang lalu seperti, titik kordinat, dokumen lingkungan (pengecualian amdal), dan pakta integritas.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Wabup Tonny menyampaikan harapannya untuk percepatan progres dimaksud agar di penghujung tahun ini, PT. PLN sudah bisa masuk dan melakukan pekerjaan di areal kordinat yang sudah ditentukan.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">&ldquo;Besar harapan kami Pemerintah Kabupaten Toba supaya perjanjian kerja sama ini cepat terlaksana, sehingga PLN juga bisa cepat melakukan pekerjaan, tentunya, ini kerinduan masyarakat di Desa Sipagabu dan Meranti barat,&rdquo; ucap Wabup Tonny.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Turut hadir perwakilan PLN Wilayah UP3, Perwakilan Dinas Kehutanan Provinsi Sumut, Sekretaris Dinas Lingkungan Hidup dan Kehutanan Kabupaten Toba, Lahsa Junianna Simanullang, S.STP, M.Si. (MC Toba)</p>', 'content_20221109112124376.jpg', '', '', '', '', 1),
(29, 1, 'Ikut Mencegah Stunting, Kader Pembantu Pembina Keluarga Berencana Desa Diapresiasi Bupati Toba', 'ikut-mencegah-stunting-kader-pembantu-pembina-keluarga-berencana-desa-diapresiasi-bupati-toba', '2022-09-09', '<p>Sebagai bentuk apresiasi Pemerintah Kabupaten Toba atas kinerja Pembantu Pembina Keluarga Berencana Desa (PPKBD) dan Sub PPKBD se-Kecamatan Laguboti, Bupati Toba, Poltak Sitorus menghadiri acara Pembinaan dan Penyerahan Honor yang berlangsung di Aula Kantor Camat Laguboti, Kabupaten Toba Provinsi Sumatra Utara,Rabu, (9/11/2022)</p><br>\r\n\r\n<p>Jumlah kader PPKBD di Kecamatan Laguboti yang mencakup 22 desa dan 1 kelurahan adalah sebanyak 23 orang dan terdapat 68 orang sebagai kader Sub PPKBD.<p> <br>\r\n\r\n<p>Adapun tugas dari kader PPKBD adalah sebagai perpanjangan tangan pemerintah dalam pengendalian penduduk dan keluarga berencana untuk mewujudkan ketahanan keluarga. Kader PPKBD membantu menyebarluaskan informasi KB kepada masyarakat dalam menciptakan keluarga sejahtera.</p><br>\r\n\r\n<p>Dalam sambutannya, Bupati Poltak Sitorus menyampaikan terima kasih atas peran para kader PPKBD dalam menciptakan keluarga sejahtera termasuk dalam pencegahan stunting sejak dini. Meskipun mendapat honor yang sedikit, Bupati Toba mendorong para kader agar tetap bekerja maksimal untuk membantu masyarakat.<p><br>\r\n\r\n<p>â€œSititi ma sigompa, golang golang pangarahutna, otik na boi tarpatupa, godang ma pinasuna. Sedikit yang bisa kita berikan, hendaknya para kader tetap semangat dalam mengerjakan tugas dan menjadi berkat dengan menolong sesama,â€ ucap Bupati.</p>\r\n\r\n<p>Sesuai laporan Kepala Dinas Pengendalian Penduduk dan Keluarga Berencana dr. Juliwan Hutapea pada Acara Pembinaan dan Penyerahan Honor PPKBD Se-Kecamatan Laguboti, bahwa setiap kader PPKBD menerima honor sebesar Rp. 100.000/bulan. Pembayaran dilakukan sekaligus untuk masa kerja 1 (satu) tahun.<p>\r\n\r\n<p>Atas kehadiran Bupati Toba pada Acara Pembinaan dan Penyerahan Honor PPKBD Se-Kecamatan Laguboti, Camat Laguboti Aprilla Nessy Tampubolon menyampaikan terima kasih. Camat Laguboti selanjutnya mendorong para kader agar semangat menjalankan tugas untuk memberikan penyuluhan dan konseling terkait pengendalian penduduk dan keluarga berencana kepada masyarakat.<p>\r\n\r\n<p>Turut mendampingi bupati, Plt. Kadis Kominfo Sesmon TB Butarbutar. (MC Toba)</p>', 'content_20221109112324899.jpg', '', '', '', '', 1),
(32, 1, 'Bupati Toba Berbangga Atas Kinerja Pengurus PKK Toba.', 'bupati-toba-berbangga-atas-kinerja-pengurus-pkk-toba', '2022-09-09', '<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Bupati Toba, Poltak Sitorus berbangga dan menyampaikan apresiasi atas kinerja yang telah ditunjukkan oleh Tim Penggerak (TP) Pemberdayaan Kesejahteraan Keluarga (PKK) Kabupaten Toba, semenjak dilantik tahun 2021 hingga saat ini.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Hal tersebut disampaikan Bupati Poltak Sitorus saat membuka rapat koordinasi yang digelar di kantor Bupati Toba, Balige, Kabupaten Toba, Provinsi Sumatra Utara, Rabu (9/11/2022).</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Rapat tersebut dihadiri sejumlah Pengurus TP. PKK Kabupaten Toba, Pimpinan Organisasi Perangkat Daerah (OPD), dan para Camat se-Kabupaten Toba. Tujuan rapat untuk sinkronisasi program dan kegiatan pada OPD terkait, untuk mendukung keberhasilan pelaksanaan kegiatan TP PKK Kabupaten Toba pada tahun 2023.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">&ldquo;Beruntung kita punya pengurus yang tetap giat, dan bekerja keras agar masyarakat Toba bisa lebih berdaya dan sejahtera, walau dukungan anggaran buat mereka terbatas,&rdquo; ucap Poltak Sitorus.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Bupati berharap melalui rapat ini, Pimpinan OPD lebih memahami peran penting PKK untuk kesejahteraan masyarakat. Lebih lanjut bupati meminta OPD tidak menyepelekan kegiatan PKK, namun harus didukung penuh.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">&ldquo;10 program pokok PKK harus terlaksana dengan baik. Oleh karenanya dukungan anggaran lewat OPD sangat penting. Kalau TP. PKK tidak bergerak, yang rugi adalah masyarakat,&rdquo; ucap bupati.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Pada pertemuan tersebut Pengurus TP. PKK Toba memaparkan kondisi mereka saat ini serta rencana kegiatan dan kebutuhan dana untuk tahun 2023.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Diantaranya menurunkan angka stunting, pembuatan rumah bibit di beberapa desa binaan, pemberian bantuan bibit dan permodalan, dan sosialisasi terkait pencegahan kekerasan dalam rumah tangga.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Ketua TP PKK Toba, Ny. Rita Marlina Poltak Sitorus berharap dukungan penuh dan kerjasama seluruh OPD, agar mereka dapat bekerja maksimal.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">&ldquo;Kalau Tim Penggerak PKK bekerja maksimal, 50% kegiatan pemerintah daerah bisa terbantu,&rdquo; kata Ny. Rita Marlina Poltak Sitorus. (MC Toba)</p>', 'content_20221109113341951.jpg', '', '', '', '', 1),
(33, 1, 'Pemkab Toba Sosialisasikan F1H2O Pada Pesta Puncak Tahun Kesehatian dan Ulang Tahun Ke-21 HKBP Resor Tampubolon', 'pemkab-toba-sosialisasikan-f1h2o-pada-pesta-puncak-tahun-kesehatian-dan-ulang-tahun-ke-21-hkbp-resor-tampubolon', '2022-11-08', '<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Bupati Toba, Poltak Sitorus kembali menyampaikan kepada seluruh masyarakat Kabupaten Toba agar bersiap menyambut ribuan wisatawan yang akan datang pada perhelatan akbar Boat Race International F1H2O pada 24-26 Februari 2023.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Hal ini disampaikan Bupati Poltak Sitorus dalam kata sambutannya seusai mengikuti ibadah Pesta Puncak Tahun Kesehatian dan Ulang Tahun Ke-21 Gereja Huria Kristen Batak Protestan (HKBP) Resor Tampubolon di Desa Sibolahotang, Kecamatan Balige, Kabupaten Toba, Provinsi Sumatra Utara, Minggu (6/11/2022).</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Sebelumnya Bupati Poltak Sitorus mengucapkan selamat Ulang Tahun ke-21 Gereja HKBP Resor Tampubolon dan Perayaan Puncak Tahun Kesehatian Tahun 2022.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Selain mengajak warga agar menyambut tamu atau wisatawan yang berkunjung ke Danau Toba di wilayah Kabupaten Toba dengan keramahan dan salam Batak Naraja, Bupati juga meminta warga supaya mau mengambil tambahan pendapatan dengan menyediakan 1 atau 2 kamar di rumah menjadi penginapan yang bersih ala homestay.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Hal berikutnya, Bupati Poltak Sitorus meminta para pelajar SD, SMP, dan SMA yang meraih juara 1-3 agar tampil ke depan mimbar dan menerima apresiasi berupa tali asih dari Bupati.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Bupati Poltak menyebutkan Pemkab Toba terus mendorong peningkatan sumber daya manusia, khususnya bagi siswa SMP agar bisa masuk melanjutkan pendidikan ke SMA unggulan di Toba yaitu Del atau Yayasan TB Soposurung.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Bagi siswa yang berhasil diterima masuk, tetapi orang tuanya kurang mampu membiayai maka Pemkab Toba akan memberikan bea siswa.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Dalam ibadah yang digelar sebelum acara seremoni,Sekretaris Distrik XI HKBP Toba Hasundutan,Pdt.Dr.Halomoan Marpaung, M.Ps menyampaikan khotbah dengan mengutip ayat Alkitab 2 Tesalonika 2:13-17 yaitu &ldquo;Paulus bersyukur atas kasih Allah yang memilih UmatNya.&rdquo;</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Disebutkan, berbeda dengan &ldquo;memilih&rdquo; di dunia, memilih kalau sesorang baik. Tetapi Tuhan memilih bukan karena kebaikan kita tetapi supaya kita baik dan berbuah. Ini sejalan dengan Yohanes 15:16 yang menyebutkan &ldquo;dipilih, ditetapkan supaya berbuah&rdquo; dalam berbagai aspek kehidupan.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Manusia yang Tuhan pilih merespons kebaikan Tuhan dengan berdiri teguh dan jangan goyah oleh berbagai suka dan duka dalam kehidupan. Supaya teguh, setia dan taat hanya kepada Tuhan Allah.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">&ldquo;Kita juga bersyukur atas kasih Allah yang telah memilih kita menjadi umatNya, menjadi jemaat Gereja HKBP Tampubolon yang merayakan ulang tahun ke- 21 menjadi Resor pada momen Perayaan Puncak Tahun Kesehatian,&rdquo; kata Pdt Halomoan Marpaung.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Seusai ibadah dilanjutkan dengan syukuran ulang tahun ke -21 sebagai Resor Gereja HKBP Tampubolon. Pendeta Resor, Pdt.Singhan Pardede,M.Th. memimpin seremoninya.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Ditandai dengan meniup lilin kue ulang tahun dan membagi-bagikan kepada penatua gereja, utusan jemaat, dan Bupati Poltak Sitorus diiringi lagu selamat ulang tahun.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Seusai acara kata-kata sambutan,<br style=\"box-sizing: border-box;\" />Pdt.Singhan Pardede mewakili penatua dan jemaat menyampaikan ucapan terima kasih kepada jemaat yang membawa persembahan untuk kemuliaan nama Tuhan.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Ucapan terima kasih juga disampaikan kepada Bupati Toba Poltak Sitorus yang menyerahkan tali asih. &ldquo;Diberkati Tuhanlah Bapak Bupati,&rdquo; katanya.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Menariknya dalam acara hiburan, tampil penyanyi trio, Pdt.Singhan Pardede,Bupati Poltak Sitorus,dan Pdt.Halomoan Marpaung mempersembahkan lagu berjudul Tangiang ni Dainang.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Kemudian ada persembahan tarian tortor Batak dari para anak Sekolah Minggu .</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Hasil pantauan, di sekitar lokasi ,Dinas Kesehatan melalui Puskesmas Tandang Buhit , Balige melakukan pemeriksaan kesehatan gratis seperti pemeriksaan gula darah dan penyakit tidak menular bagi warga jemaat.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\">Turut hadir mendampingi bupati, Sekdakab Toba Augus Sitorus, Ny Rita Marlina Poltak Sitorus, Ny.Irmayanti Augus Sitorus, Asisten Administrasi Umum, sejumlah pimpinan perangkat daerah, Camat Balige, Kades Sibolahotang SAS, Kades Sariburaja Janji Maria, dan Kabag Setdakab (MC Toba)</p>', 'content_20221109113534821.jpg', '', '', '', '', 1),
(42, 8, 'Canaval', 'canaval', '2022-12-06', '<p>dfdf</p>', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpcontentcategory`
--

CREATE TABLE `cpcontentcategory` (
  `id` int(10) NOT NULL,
  `vCategory` varchar(50) DEFAULT '',
  `vPermalink` varchar(100) DEFAULT NULL,
  `iComment` int(1) NOT NULL DEFAULT '0',
  `iModule` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpcontentcategory`
--

INSERT INTO `cpcontentcategory` (`id`, `vCategory`, `vPermalink`, `iComment`, `iModule`) VALUES
(1, 'Seputar Toba', 'seputar-toba', 1, 1),
(6, 'Pengumuman Toba', 'pengumuman', 0, 0),
(8, 'Event Toba', 'event', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpcontentcomment`
--

CREATE TABLE `cpcontentcomment` (
  `id` int(10) NOT NULL,
  `idContent` int(10) DEFAULT '0',
  `vName` varchar(80) DEFAULT '',
  `vEmail` varchar(60) DEFAULT '',
  `vURL` varchar(70) DEFAULT '',
  `tComment` text,
  `vIP` varchar(16) DEFAULT '',
  `dPublishDate` date DEFAULT NULL,
  `iStatus` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpcontentmodule`
--

CREATE TABLE `cpcontentmodule` (
  `id` int(10) NOT NULL,
  `idContent` int(10) DEFAULT NULL,
  `vName` varchar(100) DEFAULT NULL,
  `vData` text,
  `vPicture` varchar(100) DEFAULT NULL,
  `vModule` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpcontentmodule`
--

INSERT INTO `cpcontentmodule` (`id`, `idContent`, `vName`, `vData`, `vPicture`, `vModule`) VALUES
(16, 7, 'pic4', 'sub_3_2017618104950.jpg', NULL, 'content'),
(13, 7, 'pic1', 'sub_0_2017618104919.jpg', NULL, 'content'),
(14, 7, 'pic2', 'sub_1_2017618104919.jpg', NULL, 'content'),
(15, 7, 'pic3', 'sub_2_2017618104919.jpg', NULL, 'content'),
(12, 7, 'optionaldesc', '<p>Perjalanan Tour:<br><br>Kumpul di Medan<br><br>Berangkat menuju parapat<br><br>Makan Siang di Siantar<br><br>Makan Malam di Parapat<br><br>Sewa Kapal<br></p>', NULL, 'content'),
(10, 7, 'price', '3000000', NULL, 'content'),
(11, 7, 'todate', '2017-06-17', NULL, 'content'),
(17, 7, 'pic5', 'sub_4_2017618104919.jpg', NULL, 'content'),
(18, 7, 'pic6', 'sub_5_2017618104919.jpg', NULL, 'content'),
(19, 7, 'day', '15 Hari', NULL, 'content'),
(20, 8, 'star', '4', NULL, 'content'),
(21, 8, 'address', 'Jln. Merdeka No. 12 Parapat', NULL, 'content'),
(22, 8, 'lat', '2.6657932563379045', NULL, 'content'),
(23, 8, 'lng', '98.93839793777465', NULL, 'content'),
(24, 8, 'zoom', '16', NULL, 'content'),
(25, 8, 'phone', '0812222222', NULL, 'content'),
(26, 8, 'wa', '0812222222', NULL, 'content'),
(27, 8, 'email', 'support@warungwebsite.com', NULL, 'content'),
(28, 8, 'url', 'www.yaya.com', NULL, 'content'),
(29, 8, 'reviewrate', '8', NULL, 'content'),
(30, 8, 'price', '300000', NULL, 'content'),
(31, 8, 'ac', 'yes', NULL, 'content'),
(32, 8, 'ballroom', 'yes', NULL, 'content'),
(33, 8, 'parking', 'yes', NULL, 'content'),
(34, 8, 'hours', 'yes', NULL, 'content'),
(35, 8, 'elevator', 'yes', NULL, 'content'),
(36, 8, 'resto', 'yes', NULL, 'content'),
(37, 8, 'wifi', 'yes', NULL, 'content'),
(38, 8, 'swimming', 'yes', NULL, 'content'),
(39, 8, 'pic1', 'sub_0_2017619064215.jpg', NULL, 'content'),
(40, 8, 'pic2', 'sub_1_2017619064215.jpg', NULL, 'content'),
(41, 8, 'pic3', 'sub_2_2017619064215.jpg', NULL, 'content'),
(42, 8, 'pic4', 'sub_3_2017619064215.jpg', NULL, 'content'),
(43, 8, 'pic5', 'sub_4_2017619064215.jpg', NULL, 'content'),
(44, 8, 'pic6', 'sub_5_2017619064215.jpg', NULL, 'content'),
(45, 8, 'pic7', 'sub_6_2017619064215.jpg', NULL, 'content'),
(46, 8, 'pic8', 'sub_7_2017619064215.jpg', NULL, 'content'),
(47, 8, 'pic9', 'sub_8_2017619064215.jpg', NULL, 'content'),
(48, 8, 'pic10', 'sub_9_2017619064215.jpg', NULL, 'content'),
(50, 9, 'address', 'Jln. Samosir No. 12', NULL, 'content'),
(51, 9, 'lat', '2.667165060441338', NULL, 'content'),
(52, 9, 'lng', '98.83814769363403', NULL, 'content'),
(53, 9, 'zoom', '11', NULL, 'content'),
(54, 9, 'phone', '2323232', NULL, 'content'),
(55, 9, 'wa', '3221212', NULL, 'content'),
(56, 9, 'email', 'support@warungwebsite.com', NULL, 'content'),
(57, 9, 'url', 'www.yaya.com', NULL, 'content'),
(78, 10, 'address', 'Jln. Merdeka No. 12 Parapat', NULL, 'content'),
(60, 9, 'ac', 'yes', NULL, 'content'),
(80, 10, 'lng', '98.93839793777465', NULL, 'content'),
(62, 9, 'parking', 'yes', NULL, 'content'),
(63, 9, 'hours', 'yes', NULL, 'content'),
(66, 9, 'wifi', 'yes', NULL, 'content'),
(79, 10, 'lat', '2.6657932563379045', NULL, 'content'),
(68, 9, 'pic1', 'sub_0_2017620050457.jpg', NULL, 'content'),
(69, 9, 'pic2', '', NULL, 'content'),
(70, 9, 'pic3', '', NULL, 'content'),
(71, 9, 'pic4', '', NULL, 'content'),
(72, 9, 'pic5', '', NULL, 'content'),
(73, 9, 'pic6', '', NULL, 'content'),
(74, 9, 'pic7', '', NULL, 'content'),
(75, 9, 'pic8', '', NULL, 'content'),
(76, 9, 'pic9', '', NULL, 'content'),
(77, 9, 'pic10', '', NULL, 'content'),
(81, 10, 'zoom', '9', NULL, 'content'),
(82, 10, 'phone', '0812222222', NULL, 'content'),
(83, 10, 'wa', '0812222222', NULL, 'content'),
(84, 10, 'email', 'admin@warungwebsite.com', NULL, 'content'),
(85, 10, 'url', 'www.yaya.com', NULL, 'content'),
(86, 10, 'antarjemput', 'yes', NULL, 'content'),
(87, 10, 'rentalsupir', 'yes', NULL, 'content'),
(88, 10, 'rental', 'yes', NULL, 'content'),
(89, 10, 'bus', 'yes', NULL, 'content'),
(90, 10, 'pic1', 'sub_0_2017620054603.jpg', NULL, 'content'),
(91, 10, 'pic2', '', NULL, 'content'),
(92, 10, 'pic3', '', NULL, 'content'),
(93, 10, 'pic4', '', NULL, 'content'),
(94, 10, 'pic5', '', NULL, 'content'),
(95, 10, 'pic6', '', NULL, 'content'),
(96, 11, 'address', 'Jln. Sutomo No. 13', NULL, 'content'),
(97, 11, 'lat', '2.945608518795688', NULL, 'content'),
(98, 11, 'lng', '99.06474071121215', NULL, 'content'),
(99, 11, 'zoom', '9', NULL, 'content'),
(100, 11, 'phone', '0812222222', NULL, 'content'),
(101, 11, 'wa', '0812222222', NULL, 'content'),
(102, 11, 'email', 'admin@warungwebsite.com', NULL, 'content'),
(103, 11, 'url', 'www.yaya.com', NULL, 'content'),
(104, 11, 'ticketing', 'yes', NULL, 'content'),
(105, 11, 'hotel', 'yes', NULL, 'content'),
(106, 11, 'tour', 'yes', NULL, 'content'),
(107, 11, 'passport', 'yes', NULL, 'content'),
(108, 11, 'taxi', 'yes', NULL, 'content'),
(109, 11, 'others', 'yes', NULL, 'content'),
(110, 11, 'pic1', 'sub_0_2017620063500.jpg', NULL, 'content'),
(111, 11, 'pic2', 'sub_1_2017620063500.jpg', NULL, 'content'),
(112, 11, 'pic3', '', NULL, 'content'),
(113, 11, 'pic4', '', NULL, 'content'),
(114, 11, 'pic5', '', NULL, 'content'),
(115, 11, 'pic6', '', NULL, 'content'),
(116, 12, 'address', 'Diatas gunung pusuk buhit', NULL, 'content'),
(117, 12, 'lat', '2.6085190798175075', NULL, 'content'),
(118, 12, 'lng', '98.67841678237914', NULL, 'content'),
(119, 12, 'zoom', '11', NULL, 'content'),
(120, 12, 'youtube', 'https://www.youtube.com/watch?v=8c4IGO_HjfI', NULL, 'content'),
(121, 12, 'pic1', 'sub_0_2017620090128.jpg', NULL, 'content'),
(122, 12, 'pic2', '', NULL, 'content'),
(123, 12, 'pic3', '', NULL, 'content'),
(124, 12, 'pic4', '', NULL, 'content'),
(125, 12, 'pic5', '', NULL, 'content'),
(126, 12, 'pic6', '', NULL, 'content'),
(127, 12, 'pic7', '', NULL, 'content'),
(128, 12, 'pic8', '', NULL, 'content'),
(129, 12, 'pic9', '', NULL, 'content'),
(130, 12, 'pic10', '', NULL, 'content'),
(147, 90, 'link_content', '                <div class=\"font-size-md font-weight-semibold text-dark mb-4\">\r\n                  Link OPD\r\n                </div>\r\n                <ul class=\"list-group list-group-flush list-group-borderless\">\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a\r\n                      href=\"\"\r\n                      class=\"link-hover-secondary-primary\"\r\n                      >Dinas Pendidikan</a\r\n                    >\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"#\" class=\"link-hover-secondary-primary\">Dinas Kehutanan</a>\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"#\" class=\"link-hover-secondary-primary\">Dinas Pariwisata</a>\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"#\" class=\"link-hover-secondary-primary\"\r\n                      >Dinas Komunikasi dan Informasi</a\r\n                    >\r\n                  </li>\r\n                </ul>', '', 'page'),
(141, 90, 'social_content', '\r\n <ul class=\"list-inline\">\r\n<li class=\"list-inline-item mr-5\">\r\n<a target=\"_blank\" title=\"Twitter\" href=\"#\">\r\n<i class=\"fab fa-twitter\">\r\n</i>\r\n<span>Twitter</span>\r\n</a>\r\n</li>\r\n<li class=\"list-inline-item mr-5\">\r\n<a target=\"_blank\" title=\"Facebook\" href=\"#\">\r\n<i class=\"fab fa-facebook-f\">\r\n</i>\r\n<span>Facebook</span>\r\n</a>\r\n</li>\r\n<li class=\"list-inline-item mr-5\">\r\n<a target=\"_blank\" title=\"Google plus\" href=\"#\">\r\n<svg class=\"icon icon-google-plus-symbol\">\r\n<use xlink:href=\"#icon-google-plus-symbol\"></use>\r\n</svg>\r\n<span>Google plus</span>\r\n</a>\r\n</li>\r\n<li class=\"list-inline-item mr-5\">\r\n<a target=\"_blank\" title=\"Instagram\" href=\"#\">\r\n<svg class=\"icon icon-instagram\">\r\n<use xlink:href=\"#icon-instagram\"></use>\r\n</svg>\r\n<span>Instagram</span>\r\n</a>\r\n</li>\r\n<li class=\"list-inline-item mr-5\">\r\n<a target=\"_blank\" title=\"Rss\" href=\"#\">\r\n<i class=\"fas fa-rss\"></i>\r\n<span>Rss</span>\r\n</a>\r\n</li>\r\n</ul>', '', 'page'),
(146, 90, 'explore_content', '                <div class=\"font-size-md font-weight-semibold text-dark mb-4\">\r\n                  Link Toba\r\n                </div>\r\n                <ul class=\"list-group list-group-flush list-group-borderless\">\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a\r\n                      href=\"\"\r\n                      class=\"link-hover-secondary-primary\"\r\n                      >Sekilas Daerah</a\r\n                    >\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"\" class=\"link-hover-secondary-primary\">Visi Misi</a>\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"\" class=\"link-hover-secondary-primary\">Sejarah Daerah</a>\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"\" class=\"link-hover-secondary-primary\"\r\n                      >Investors</a\r\n                    >\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a\r\n                      href=\"\"\r\n                      class=\"link-hover-secondary-primary\"\r\n                      >Hubungi Kami</a\r\n                    >\r\n                  </li>\r\n                  <li class=\"list-group-item px-0 lh-1625 bg-transparent py-1\">\r\n                    <a href=\"#\" class=\"link-hover-secondary-primary\">Offices</a>\r\n                  </li>\r\n                </ul>', '', 'page'),
(148, 90, 'contact_content', '                  <div class=\"font-size-md font-weight-semibold text-dark mb-4\">\r\n                    Alamat                  </div>\r\n                  <p class=\"mb-0\">\r\n                    Jl. Sutomo Pagar Batu No. 1, Balige\r\n<br />\r\n                    Kabupaten Toba Samosir<br />\r\n                    Sumatera Utara\r\n                  </p>', '', 'page'),
(217, 157, 'address', 'Kabupaten Toba', '', 'page'),
(218, 157, 'description', 'Merupakan event yang telah dilaksanakan sejak 1970-an yang dulu dikenal dengan sebutan Pesta Danau Toba.', '', 'page'),
(219, 157, 'date', '22 April 2021\r\n', '', 'page'),
(220, 157, 'status', '<div class=\"badge badge-warning\">Event Closed</div>', '', 'page'),
(221, 158, 'address', 'Kabupaten Toba', '', 'page'),
(222, 158, 'date', '17 April 2021\r\n', '', 'page'),
(223, 158, 'description', 'Kawasan wisata Danau Toba bakal menggelar Event yang meriah, yakni Karnaval Pesona Danau Toba 2020. Event yang berpusat di Kota Balige, Sumatera Utara Karnaval Pesona Danau Toba akan berlangsung pada 03-05 Juli mendatang.', '', 'page'),
(225, 153, 'detail_event', '           \r\n<div class=\"card p-4 widget border-0 bg-gray-06 rounded-0 mb-6\">\r\n  <div class=\"card-title d-flex mb-0 font-size-md font-weight-semibold text-dark text-uppercase border-bottom pb-2 lh-1\">\r\n  <span>Event details</span>\r\n  </div>\r\n  <div class=\"card-body px-0 pb-0\">\r\n  <ul class=\"list-group list-group-flush\">\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">Start date</label>\r\n  <span class=\"ml-auto font-weight-semibold\">17 April 2021</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">End date</label>\r\n  <span class=\"ml-auto font-weight-semibold\">18 April 2021</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">Time</label>\r\n  <span class=\"ml-auto font-weight-semibold\">09:00 am</span>\r\n  </li>\r\n  </li>\r\n  </ul>\r\n  </div>\r\n  </div>', '', 'page'),
(226, 153, 'maps', '            <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n              <div id=\"googleMap\" data-latlng=\"2.323929458350241, 99.05095258134313\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n              <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n                <div class=\"card-body px-0 py-2\">\r\n                  <ul class=\"list-group list-group-flush\">\r\n                    <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                      <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                      <span class=\"card-text\">Jl. Soposurung</span>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>', '', 'page'),
(227, 157, 'detail_event', '           \r\n<div class=\"card p-4 widget border-0 bg-gray-06 rounded-0 mb-6\">\r\n  <div class=\"card-title d-flex mb-0 font-size-md font-weight-semibold text-dark text-uppercase border-bottom pb-2 lh-1\">\r\n  <span>Event details</span>\r\n  </div>\r\n  <div class=\"card-body px-0 pb-0\">\r\n  <ul class=\"list-group list-group-flush\">\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">Start date</label>\r\n  <span class=\"ml-auto font-weight-semibold\">22 April 2021</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">End date</label>\r\n  <span class=\"ml-auto font-weight-semibold\">23 April 2021</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">Time</label>\r\n  <span class=\"ml-auto font-weight-semibold\">09:00 am</span>\r\n  </li>\r\n  </li>\r\n  </ul>\r\n  </div>\r\n  </div>', '', 'page'),
(228, 158, 'detail_event', '           \r\n<div class=\"card p-4 widget border-0 bg-gray-06 rounded-0 mb-6\">\r\n  <div class=\"card-title d-flex mb-0 font-size-md font-weight-semibold text-dark text-uppercase border-bottom pb-2 lh-1\">\r\n  <span>Event details</span>\r\n  </div>\r\n  <div class=\"card-body px-0 pb-0\">\r\n  <ul class=\"list-group list-group-flush\">\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">Start date</label>\r\n  <span class=\"ml-auto font-weight-semibold\">17 April 2021</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">End date</label>\r\n  <span class=\"ml-auto font-weight-semibold\">18 April 2021</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0\">Time</label>\r\n  <span class=\"ml-auto font-weight-semibold\">09:00 am</span>\r\n  </li>\r\n  </li>\r\n  </ul>\r\n  </div>\r\n  </div>', '', 'page'),
(229, 157, 'maps', '            <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n              <div id=\"googleMap\" data-latlng=\"2.334655177090961, 99.0832519485498\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n              <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n                <div class=\"card-body px-0 py-2\">\r\n                  <ul class=\"list-group list-group-flush\">\r\n                    <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                      <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                      <span class=\"card-text\">Kabupaten Toba</span>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>', '', 'page'),
(230, 158, 'maps', '            <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n              <div id=\"googleMap\" data-latlng=\"2.334655177090961, 99.0832519485498\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n              <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n                <div class=\"card-body px-0 py-2\">\r\n                  <ul class=\"list-group list-group-flush\">\r\n                    <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                      <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                      <span class=\"card-text\">Kabupaten Toba</span>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>', '', 'page'),
(231, 157, 'alert', '<div class=\"alert alert-warning\" role=\"alert\">\r\n  <i class=\"fas fa-exclamation-triangle\"></i> Event Sudah Berakhir\r\n</div>', '', 'page'),
(232, 158, 'alert', '<div class=\"alert alert-warning\" role=\"alert\">\r\n  <i class=\"fas fa-exclamation-triangle\"></i> Event Sudah Berakhir\r\n</div>', '', 'page'),
(233, 108, 'maps', '            <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n              <div id=\"googleMap\" data-latlng=\"2.323929458350241, 99.05095258134313\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n              <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n                <div class=\"card-body px-0 py-2\">\r\n                  <ul class=\"list-group list-group-flush\">\r\n                    <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                      <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                      <span class=\"card-text\">Kabupaten Toba</span>\r\n                    </li>\r\n<li  class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n<a class=\"card-text\" href=\"https://maps.google.com/maps?ll=2.328455,99.252233&z=9&t=m&hl=en-US&gl=US&mapclient=embed&q=Toba%20North%20Sumatra\" target=\"_blank\"><i class=\"fas fa-external-link-square-alt\"></i> View large map</a>\r\n</li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>', '', 'page'),
(175, 92, 'app_pkk', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">Aplikasi PKK</a></h5>\r\n<h6 class=\"text-center\">Pemberdayaan Kesejahteraan Keluarga\r\nKabupaten Toba</h6>', 'pm_20221109033820523.png', 'page'),
(176, 92, 'prp_2', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">PRP2</a></h5> <h6 class=\"text-center\">Progress Report Pengendalian Pembangunan</h6>', 'pm_20221109034125172.jpg', 'page'),
(178, 92, 'e_email', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">E-Email</a></h5> <h6 class=\"text-center\">Server Email Pemerintah Kabupaten Toba</h6>', 'pm_20221109034406322.png', 'page'),
(179, 92, 'e_pegawai', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">E-Pegawai</a></h5> <h6 class=\"text-center\">Aplikasi E-Pengawai Pemerintah Kabupaten Toba</h6>', 'pm_20221109034244758.png', 'page'),
(181, 92, 'lppd', '	<h5\r\nclass=\"card-title\r\nmb-2\r\ntext-center\"><a\r\nhref=\"#\"\r\nclass=\"btn\r\nbtn-sm\r\nbtn-danger\">LPPD</a></h5> <h6\r\nclass=\"text-center\">E-Laporan Penyelenggaraan Pemerintahan Daerah</h6>', 'pm_20221109034328592.png', 'page'),
(182, 92, 'dekranasda', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">DEKRANASDA</a></h5> <h6 class=\"text-center\">Dewan Kerajinan Nasional Kbaupaten Toba</h6>', 'pm_20221109034048376.png', 'page'),
(183, 92, 'e_planning', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">E-Planning</a></h5> <h6 class=\"text-center\">Aplikasi E-Planning Pemerintah Kabupaten Toba</h6>', 'pm_20221109034154925.png', 'page'),
(184, 92, 'jdih', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">JDIH</a></h5> <h6 class=\"text-center\">Jaringan Dokumentasi Dan Informasi Hukum</h6>', 'pm_20221109033910303.png', 'page'),
(185, 92, 'e_keuangan', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">E-Keuangan</a></h5> <h6 class=\"text-center\">Aplikasi E-Budgetting Pemerintah Kabupaten Toba</h6>', 'pm_20221109034217491.png', 'page'),
(186, 92, 'lpse', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">LPSE</a></h5> <h6 class=\"text-center\">Sistem Pengadaan Secara Elektronik</h6>', 'pm_20221109034426870.png', 'page'),
(188, 92, 'opd', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">OPD</a></h5> <h6 class=\"text-center\">Organisasi Perangkat Daerah</h6>', 'pm_20221109034502166.png', 'page'),
(191, 92, 'covid_19', '<h5 class=\"card-title mb-2 text-center\"><a href=\"#\" class=\"btn btn-sm btn-danger\">COVID-19</a></h5>\r\n<h6 class=\"text-center\">Peta Sebaran Covid-19 Kabupaten Toba</h6>', 'pm_20221109034022839.png', 'page'),
(192, 92, 'e_lapor', '<h5 class=\"card-title mb-2 text-center\"><a href=\"https:/www.lapor.go.id\" class=\"btn btn-sm btn-danger\">Lapor</a></h5> <h6 class=\"text-center\">Layanan Aspirasi Dan Pengaduan Online</h6>', 'pm_20221109034651932.png', 'page'),
(207, 31, 'Test Oke', 'Oke Testtt Test', '', 'content'),
(211, 153, 'description', 'Soposurung Art Festival sebagai bagian dari Calender of Event Pariwisata Danau Toba merupakan kegiatan yang dikemas dalam bentuk event festival seni dan budaya masyarakat setempat.', '', 'page'),
(212, 153, 'status', '<div class=\"badge badge-warning\">Event Closed</div>', '', 'page'),
(213, 153, 'alert', '<div class=\"alert alert-warning\" role=\"alert\">\r\n  <i class=\"fas fa-exclamation-triangle\"></i> Event Sudah Berakhir\r\n</div>', '', 'page'),
(214, 153, 'address', 'Jl. Soposurung\r\n', '', 'page'),
(215, 153, 'address_link', 'https://goo.gl/maps/ZarhhThj2Xhx71fx6', '', 'page'),
(216, 153, 'date', '17 April 2021', '', 'page'),
(234, 109, 'maps', '            <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n              <div id=\"googleMap\" data-latlng=\"2.323929458350241, 99.05095258134313\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n              <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n                <div class=\"card-body px-0 py-2\">\r\n                  <ul class=\"list-group list-group-flush\">\r\n                    <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                      <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                      <span class=\"card-text\">Kabupaten Toba</span>\r\n                    </li>\r\n<li  class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n<a class=\"card-text\" href=\"https://maps.google.com/maps?ll=2.328455,99.252233&z=9&t=m&hl=en-US&gl=US&mapclient=embed&q=Toba%20North%20Sumatra\" target=\"_blank\"><i class=\"fas fa-external-link-square-alt\"></i> View large map</a>\r\n</li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>', '', 'page'),
(235, 120, 'action_form_mail', 'mailto:admin@tobakab.go.id', '', 'page'),
(236, 120, 'detail', '           \r\n<div class=\"card p-4 widget border-0 bg-gray-06 rounded-0 mb-6\">\r\n  <div class=\"card-title d-flex mb-0 font-size-md font-weight-semibold text-dark text-uppercase border-bottom pb-2 lh-1\">\r\n  <span>Humas</span>\r\n  </div>\r\n  <div class=\"card-body px-0 pb-0\">\r\n  <ul class=\"list-group list-group-flush\">\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0 mr-2\"><h3><i class=\"fas fa-map-marker-alt text-primary fs-5\"></i></h3></label>\r\n<span class=\"ml-auto\">\r\nJl. Sutomo Pagar Batu No. 1, Balige, Kabupaten Toba Samosir, Sumatera Utara.</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0 mr-2\"><h3><i class=\"fas fa-envelope text-primary fs-5\"></i></h3></label>\r\n  <span class=\"\">admin@tobakab.go.id</span>\r\n  </li>\r\n  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n  <label class=\"mb-0 mr-2\"><h3><i class=\"fas fa-phone text-primary\"></i></h3></label>\r\n  <span class=\"font-weight-semibold\">(0632) 22312</span>\r\n  </li>\r\n  </li>\r\n  </ul>\r\n  </div>\r\n  </div>', '', 'page'),
(237, 120, 'maps', '            <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n              <div id=\"googleMap\" data-latlng=\"2.331637,99.050924\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n              <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n                <div class=\"card-body px-0 py-2\">\r\n                  <ul class=\"list-group list-group-flush\">\r\n                    <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                      <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                      <span class=\"card-text\"><a href=\"https://goo.gl/maps/hiZo1vo69NrK66nD8\" class=\"text-gray\">Kantor Bupati Kab. Toba Samosir</a></span>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>', '', 'page');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpdoc`
--

CREATE TABLE `cpdoc` (
  `id` int(10) NOT NULL,
  `idCategory` int(10) DEFAULT NULL,
  `vDocument` varchar(100) DEFAULT NULL,
  `vFile` varchar(100) DEFAULT NULL,
  `dCreated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpdoc`
--

INSERT INTO `cpdoc` (`id`, `idCategory`, `vDocument`, `vFile`, `dCreated`) VALUES
(3, 2, 'File Pelatihan 300', 'doc_2022222112623413.docx', '2022-02-22 11:21:58'),
(2, 1, 'Document Pelatihan', 'doc_2022222110847393.docx', '2022-02-22 11:08:47'),
(4, 1, 'File PDF Dokumen Pengumuman Pelatihan', 'doc_2022314125055886.pdf', '2022-03-14 00:50:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpdoccategory`
--

CREATE TABLE `cpdoccategory` (
  `id` int(10) NOT NULL,
  `vCategory` varchar(50) DEFAULT '',
  `vPermalink` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpdoccategory`
--

INSERT INTO `cpdoccategory` (`id`, `vCategory`, `vPermalink`) VALUES
(1, 'Document Penting', 'document-penting'),
(2, 'Document Nilai', 'document-nilai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpevent`
--

CREATE TABLE `cpevent` (
  `id` int(10) NOT NULL,
  `vSeminar` varchar(200) DEFAULT NULL,
  `tDesc` text,
  `vPermalink` varchar(200) DEFAULT NULL,
  `dTanggal` datetime DEFAULT NULL,
  `dEnd` datetime DEFAULT NULL,
  `vLokasi` longtext,
  `iStatus` int(1) NOT NULL DEFAULT '0',
  `iPeserta` decimal(10,0) NOT NULL DEFAULT '0',
  `tInclude` text,
  `vSertifikat` varchar(100) DEFAULT NULL,
  `tPengaturan` text,
  `vJenisPage` varchar(10) DEFAULT NULL,
  `vDoc` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpevent`
--

INSERT INTO `cpevent` (`id`, `vSeminar`, `tDesc`, `vPermalink`, `dTanggal`, `dEnd`, `vLokasi`, `iStatus`, `iPeserta`, `tInclude`, `vSertifikat`, `tPengaturan`, `vJenisPage`, `vDoc`) VALUES
(1, 'Seminar Pelatihan 1AAA', 'Seminar ini untuk pelatihan 1', 'seminar-pelatihan-1aaa', '2022-02-10 17:00:00', '2022-02-11 12:00:00', 'Medan', 1, '20', '', '', '', '', ''),
(2, 'Seminar B', 'Seminar B', 'seminar-b', '2022-02-03 12:00:00', '2022-02-17 12:00:00', 'Medan', 1, '20', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpevent_peserta`
--

CREATE TABLE `cpevent_peserta` (
  `id` int(10) NOT NULL,
  `idSeminar` int(10) DEFAULT NULL,
  `idMember` int(30) DEFAULT NULL,
  `iStatus` int(1) NOT NULL DEFAULT '0',
  `iHadir` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpkehadiran`
--

CREATE TABLE `cpkehadiran` (
  `id` int(10) NOT NULL,
  `idSeminar` int(10) DEFAULT NULL,
  `idPeserta` int(10) DEFAULT NULL,
  `iStatus` int(1) NOT NULL DEFAULT '0',
  `iHadir` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpkoperasi`
--

CREATE TABLE `cpkoperasi` (
  `id` int(10) NOT NULL,
  `idDiskop` varchar(100) DEFAULT NULL,
  `vKoperasi` varchar(200) DEFAULT NULL,
  `tAlamat` text,
  `vKelurahan` varchar(200) DEFAULT NULL,
  `vKecamatan` varchar(200) DEFAULT NULL,
  `vKabupaten` varchar(200) DEFAULT NULL,
  `vProvinsi` varchar(200) DEFAULT NULL,
  `vTelp` varchar(200) DEFAULT NULL,
  `vEmail` varchar(200) DEFAULT NULL,
  `vWebsite` varchar(250) DEFAULT NULL,
  `vFaks` varchar(200) DEFAULT NULL,
  `dRAT` date DEFAULT NULL,
  `cPassword` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpkoperasi`
--

INSERT INTO `cpkoperasi` (`id`, `idDiskop`, `vKoperasi`, `tAlamat`, `vKelurahan`, `vKecamatan`, `vKabupaten`, `vProvinsi`, `vTelp`, `vEmail`, `vWebsite`, `vFaks`, `dRAT`, `cPassword`) VALUES
(2, '1AAAAAB', 'Koperasi Simpan Pinjam', 'Jalan Setia Budi No. 12', 'Medan', 'Medan', 'Medan', 'Sumut', '0811111', 'koperasi@gmail.com', 'www.www.com', '', '2022-01-01', NULL),
(3, '22', 'Koperasi Simpan Pinjam Sunggal', 'Jalan Sunggal 20', 'Medan', 'Medan', 'Deli Serdang', 'Sumatera Utara', '080808080', 'sunggal@gmail.com', 'www.sunggal.com', '99897979', '2022-01-01', '439354'),
(4, '40', 'Koperasi Utama', 'Jalan Utama 20', 'Medan', 'Medan', 'Medan', 'Sumut', '080808080343', 'utama@gmail.com', 'www.utama.com', '997979', '2022-01-01', '068759'),
(16, 'oiadoiaod090', 'kljlkjad-', 'adpoiapodi', 'poaidoaido', 'poiadoaid', 'opiaodip', 'opiapodip', '09990kjakdj', '0909ad0a0', '99ad9ad', 'kjalkdj', '2022-01-01', '965332'),
(15, 'skjhgjg', 'jhgkjgkjg', 'jgjkgjgjg', 'jgjgj', 'ooiu080asdjl', 'kjhkjahsjdkasd', 'lkjkjlkasd', '897a89dasdasd', 'kjhasjdhkjasd98798', 'www.koperasi.com', '', '2022-01-01', '668123'),
(17, '988989', 'Test Koperasi A', 'Jalan Setia Budi No 12', 'Medan', 'Selayang', 'Deli Serdang', 'Sumatera Utara', '099090122211', 'koperasi2222@gmail.com', 'www.koperasi-id.com', '09090090900', '2022-01-01', '721592'),
(18, '0990AAAA', 'AA Koperasi B', 'Jln Mansyur No 12', 'Medan', 'MEdan', 'Medan', 'Sumatera Utara', '09090900090', 'medanaa@gmail.com', 'www.medan.com', 'lkjljl99oiuiou', '2022-01-01', '732474');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpkoperasi_detail`
--

CREATE TABLE `cpkoperasi_detail` (
  `id` int(10) NOT NULL,
  `idKoperasi` int(10) DEFAULT NULL,
  `vTitle` varchar(200) DEFAULT NULL,
  `tDetail` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cppage`
--

CREATE TABLE `cppage` (
  `id` int(10) NOT NULL,
  `iTopMenu` int(10) DEFAULT '0',
  `vPageName` varchar(200) DEFAULT '',
  `vPermalink` varchar(200) DEFAULT NULL,
  `vURL` varchar(100) DEFAULT '',
  `tContent` text,
  `idCategory` int(10) DEFAULT NULL,
  `dCreated` date DEFAULT NULL,
  `cURLTarget` varchar(10) DEFAULT '',
  `lbPicture` varchar(40) DEFAULT '',
  `vMetaTitle` varchar(100) DEFAULT NULL,
  `vMetaDesc` varchar(200) DEFAULT NULL,
  `vMetaKeyword` varchar(200) DEFAULT NULL,
  `iShow` int(1) DEFAULT '0',
  `iUrutan` int(3) DEFAULT '0',
  `iDefault` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cppage`
--

INSERT INTO `cppage` (`id`, `iTopMenu`, `vPageName`, `vPermalink`, `vURL`, `tContent`, `idCategory`, `dCreated`, `cURLTarget`, `lbPicture`, `vMetaTitle`, `vMetaDesc`, `vMetaKeyword`, `iShow`, `iUrutan`, `iDefault`) VALUES
(4, 0, 'TITLE', 'title', '', 'Selamat Datang di Pemerinthan Kabupaten Toba', 3, '2022-11-09', '', '', '', '', '', 1, 0, 0),
(5, 0, 'COPYRIGHT', 'copyright', '', 'Copyright Â© 2022 - Kabupaten Toba, All Rights Reserved', 3, '2022-11-09', '', '', '', '', '', 1, 0, 0),
(9, 0, 'LOGO', 'logo', '', '', 3, '2022-11-09', '', 'page_20221109021159605.png', '', '', '', 1, 0, 0),
(10, 0, 'PRELOAD', 'preload', '', '', 3, '2022-11-09', '', 'page_20221109034831591.png', '', '', '', 1, 0, 0),
(13, 0, 'FAVICON', 'favicon', '', '', 3, '2022-11-09', '', 'page_20221109021217301.png', '', '', '', 1, 0, 0),
(90, 0, 'FOOTER', 'footer', '', 'Pemerintah Kabupaten Toba', 3, '2022-11-09', '', 'page_20221109030715680.png', '', '', '', 1, 0, 0),
(91, 0, 'SECTION_1', 'section1', '', '', 3, '2022-12-05', '', '', '', '', '', 1, 0, 0),
(92, 0, 'SECTION_2', 'section2', '', '<h6 class=\"back__subtitle\">Kabupaten Toba</h6>\r\n<h2 class=\"back__tittle\"> Digitalitasi Pemerintahan Kabupaten toba</h2>', 3, '2022-11-30', '', '', '', '', '', 1, 0, 0),
(155, 0, 'SECTION_6', 'section6', '', '<section id=\"section-06\" class=\"pb-8 feature-destination pt-85 bg-warning text-white\">\r\n    <div class=\"container\">\r\n      <div class=\"align-items-center mb-7 flex-wrap flex-sm-nowrap\">\r\n        <h2 class=\"mb-3 mb-sm-0\">\r\n          <span class=\"font-weight-semibold\">Fakta Seputar Toba</span>\r\n        </h2>\r\n        <h6>Informasi Toba</h6>\r\n      </div>\r\n      \r\n      <div class=\"mb-8\">\r\n        <ul class=\"list-inline\">\r\n          <li class=\"list-inline-item px-8 mr-2\">\r\n            <div class=\"counter\">\r\n              <span class=\"d-block\"> \r\n                <span class=\"fas fa-map-signs h3\"></span>\r\n                <span\r\n              class=\"counterup h3 mb-0 lh-11 font-weight-normal\"\r\n              data-start=\"0\"\r\n              data-end=\"2021.80\"\r\n              data-decimal=\".\"\r\n              data-decimals=\"2\"\r\n              data-symbols=\"KM\"\r\n              data-duration=\"0\"\r\n              data-separator=\",\"\r\n              >0</span\r\n              >\r\n              </span>\r\n              <span class=\"text-dark d-block mt-1 h5\">Luas KM</span>\r\n            </div>\r\n          </li>\r\n          <li class=\"list-inline-item px-8\">\r\n            <div class=\"counter\">\r\n              <span class=\"d-block\">\r\n                <span class=\"fas fa-address-card h3\"></span>\r\n              <span\r\n              class=\"counterup h3 mb-0 lh-11 font-weight-normal\"\r\n              data-start=\"0\"\r\n              data-end=\"4080\"\r\n              data-decimals=\"0\"\r\n              data-duration=\"0\"\r\n              data-separator=\",\"\r\n              >0</span\r\n            >\r\n              </span>\r\n              <span class=\"text-dark d-block mt-1 h5\">Pegawai</span>\r\n            </div>\r\n          </li>\r\n          <li class=\"list-inline-item px-8\">\r\n            <div class=\"counter\"><span class=\"d-block\">\r\n              <span class=\"fas fa-smile h3\"></span>\r\n              <span\r\n                class=\"counterup h3 mb-0 lh-11 font-weight-normal\"\r\n                data-start=\"0\"\r\n                data-end=\"213924\"\r\n                data-decimals=\"0\"\r\n                data-duration=\"0\"\r\n                data-separator=\",\"\r\n                >0</span\r\n              >\r\n            </span>\r\n              <span class=\"text-dark d-block mt-1 h5\">Penduduk</span>\r\n            </div>\r\n          </li>\r\n          <li class=\"list-inline-item px-8\">\r\n            <div class=\"counter\"><span class=\"d-block\">\r\n              <span class=\"fas fa-calendar-alt h4\"></span>\r\n              <span\r\n                class=\"counterup h3 mb-0 lh-11 font-weight-normal\"\r\n                data-start=\"1945\"\r\n                data-end=\"1998\"\r\n                data-decimals=\"0\"\r\n                data-duration=\"0\"\r\n                data-separator=\"\"\r\n                >0</span\r\n              >\r\n            </span>\r\n              <span class=\"text-dark d-block mt-1 h5\">Didirikan</span>\r\n            </div>\r\n          </li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </section>', 3, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(127, 121, 'Kecamatan', 'kecamatan', '', '\r\n<div class=\"row parent\">\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/Kec.-tampahan.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Kectam</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Tampahan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/Kec.-Silaen.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecsil</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Silean</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-siantar-Narumonda.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecsinar</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Siantar Narumonda</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-Pintu-Pohan-Meranti.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecppm</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Pintu Pohan Meranti</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-balige.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecbal</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Balige</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-habinsaran.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kechab</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Habinsaran</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-porsea.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecpor</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Porsea</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-bonatua-lunasi.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecbontul</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Bunatua Lunasidisbaker</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-laguboti.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">keclag</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Laguboti</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-borbor.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecul</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Uluan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-uluan.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecbor</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Borbor</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-Lumban-julu.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecjulu</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Lumban Julu</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-sigumpar.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecsig</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Sigumpar</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-nassau.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecnas</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Nassua</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-parmaksian.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecpar</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Parmaksian</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/kec.-ajibata.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">kecaji</a>\r\n              <p class=\"card-text fs-1 text-black\">Kecamatan Ajibata</p>\r\n            </div>\r\n    </div>\r\n</div>', 1, '2022-12-06', '_self', '', '', '', '', 1, 0, 0),
(126, 121, 'Dinas', 'dinas', '', '\r\n<div class=\"row parent\">\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2022/08/DIKPORA.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient\">DIKPORA</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Pendidikan Pemuda Dan Olahraga</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISPARBUD.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Disparbud</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Parawisata Dan Kebudayaan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISKOMINFO.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">diskominfo</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Komunikasi Dan Informatika</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISDUKCAPIL.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Disdukcapil</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Kependudukan Dan Catatan Sipil</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DINKES.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Diskes</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Kesehatan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n      <div class=\"position-relative rounded-top overflow-hidden\">\r\n        <img src=\"https://tobakab.go.id/wp-content/uploads/2022/08/DISPUTR.png\" alt=\"Kabupaten Toba\">\r\n      </div>\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">disputr</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Pekerjaan Umum Dan Tata Ruang</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISPERSIP.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Dispersib</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Perpustakaan Dan Kearsipan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DPMDPPA.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">DPMDPPA</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Pemberdayaan Masyarakat, Desa, Perempuan Dan Perlindungan Anak\r\n            </p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISTAN.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">distan</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Pertanian</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISPERKIM.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">disperkim</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Perumahan Dan Kawasan Permukiman</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DPPKB.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Dppkb</a>\r\n              <p class=\"card-text fs-1 text-black text-\">Dinas Pengendali Penduduk Dam Keluarga Berencana</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISHUB.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Dishub</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Perhubungan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISKETAPANG.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Disketapang</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Ketahanan Pangan Dan Perikanan</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DISLINDUP.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">dislinkup</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Lingkungan Hidup</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/DINSOS.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">Dinsos</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Sosial</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2021/05/SATPOLPP.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">satpolpp</a>\r\n              <p class=\"card-text fs-1 text-black\">Satuan Polisi Pamong Praja</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2022/08/DKUKMPP.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">dkukmpp</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Koperasi Usaha Kecil Dan Menengah Perdagangan Dan Penrindustrian</p>\r\n            </div>\r\n    </div>\r\n    <div class=\"col-md-3 border-gradient mb-3\" data-animate=\"fadeInUp\" style=\"height: 200px;\">\r\n            <img src=\"https://tobakab.go.id/wp-content/uploads/2022/08/DPMPTSPK.png\" alt=\"Kabupaten Toba\">\r\n            <div class=\"text-center\">\r\n                <a href=\"#\" class=\"btn btn-sm btn-gradient text-uppercase\">DPMPTSPK</a>\r\n              <p class=\"card-text fs-1 text-black\">Dinas Penanaman Modal PelayananTerpadu Satu Pintu Dan KetenagaKerjaan</p>\r\n            </div>\r\n    </div>\r\n</div>', 1, '2022-12-06', '_self', '', '', '', '', 1, 0, 0),
(125, 121, 'Serikat Daerah', 'serikat-daerah', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(124, 118, 'Instansi Vertikal', 'instansi-vertikal', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(123, 118, 'FKPD', 'fkpd', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(122, 118, 'Legislatif', 'legislatif', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(121, 118, 'Eksekutif', 'eksekutif', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(120, 0, 'Hubungi Kami', 'hubungi-kami', '', '', 1, '2022-12-06', '_self', '', '', '', '', 1, 0, 0),
(119, 0, 'Berita', 'berita', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(118, 0, 'Pemerintah', 'pemerintah', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(117, 105, 'Profil Kepala Daerah', 'profil-kepala-daerah', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(116, 105, 'Arti Logo/Lambang Daerah', 'arti-logolambang-daerah', '', '<section class=\"elementor-section elementor-top-section elementor-element elementor-element-46a3bda elementor-section-boxed elementor-section-height-default elementor-section-height-default\" style=\"box-sizing: border-box; position: relative; padding: 0px; margin-top: 0px; margin-bottom: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\" data-id=\"46a3bda\" data-element_type=\"section\">\r\n<div class=\"elementor-container elementor-column-gap-default\" style=\"box-sizing: border-box; display: flex; margin-right: auto; margin-left: auto; position: relative; max-width: 1240px;\">\r\n<div class=\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4476bfc\" style=\"box-sizing: border-box; min-height: 1px; position: relative; display: flex; width: 1216px;\" data-id=\"4476bfc\" data-element_type=\"column\">\r\n<div class=\"elementor-widget-wrap elementor-element-populated\" style=\"box-sizing: border-box; position: relative; width: 1216px; flex-wrap: wrap; align-content: flex-start; display: flex; padding: 10px;\">\r\n<div class=\"elementor-element elementor-element-319df52 elementor-widget elementor-widget-image\" style=\"box-sizing: border-box; position: relative; text-align: center; width: 1196px;\" data-id=\"319df52\" data-element_type=\"widget\" data-widget_type=\"image.default\">\r\n<div class=\"elementor-widget-container\" style=\"box-sizing: border-box; transition: background 0.3s ease 0s, border 0.3s ease 0s, border-radius 0.3s ease 0s, box-shadow 0.3s ease 0s, -webkit-border-radius 0.3s ease 0s, -webkit-box-shadow 0.3s ease 0s;\">\r\n<div class=\"elementor-image\" style=\"box-sizing: border-box;\"><img style=\"box-sizing: border-box; max-width: 100%; height: auto; display: inline-block; margin: 0px auto; vertical-align: middle; border: none; border-radius: 0px; box-shadow: none;\" title=\"logo toba\" src=\"https://tobakab.go.id/wp-content/uploads/elementor/thumbs/logo-toba-p5otz1199v3piir3ur4opq7tkoz1wib6fy5aplnj2o.png\" alt=\"logo toba\" /></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<section class=\"elementor-section elementor-top-section elementor-element elementor-element-f1fbfbf elementor-section-boxed elementor-section-height-default elementor-section-height-default\" style=\"box-sizing: border-box; position: relative; padding: 0px; margin-top: 0px; margin-bottom: 0px; color: #383838; font-family: Roboto; font-size: 16px; background-color: #ffffff;\" data-id=\"f1fbfbf\" data-element_type=\"section\">\r\n<div class=\"elementor-container elementor-column-gap-default\" style=\"box-sizing: border-box; display: flex; margin-right: auto; margin-left: auto; position: relative; max-width: 1240px;\">\r\n<div class=\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4b3189f\" style=\"box-sizing: border-box; min-height: 1px; position: relative; display: flex; width: 1216px;\" data-id=\"4b3189f\" data-element_type=\"column\">\r\n<div class=\"elementor-widget-wrap elementor-element-populated\" style=\"box-sizing: border-box; position: relative; width: 1216px; flex-wrap: wrap; align-content: flex-start; display: flex; padding: 10px;\">\r\n<div class=\"elementor-element elementor-element-e4a77dd elementor-widget elementor-widget-text-editor\" style=\"box-sizing: border-box; position: relative; color: #000000; font-family: var( --e-global-typography-text-font-family ), Sans-serif; font-weight: var( --e-global-typography-text-font-weight ); width: 1196px;\" data-id=\"e4a77dd\" data-element_type=\"widget\" data-widget_type=\"text-editor.default\">\r\n<div class=\"elementor-widget-container\" style=\"box-sizing: border-box; transition: background 0.3s ease 0s, border 0.3s ease 0s, border-radius 0.3s ease 0s, box-shadow 0.3s ease 0s, -webkit-border-radius 0.3s ease 0s, -webkit-box-shadow 0.3s ease 0s;\">\r\n<div class=\"elementor-text-editor elementor-clearfix\" style=\"box-sizing: border-box; text-align: justify;\">\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Lambang Berbentuk Lonjong</span>&nbsp;dengan satu tangkai kapas di sebelah kanan berjumlah 17 kantung dan di sebelah kiri satu tangkai padi berjumlah 45 butir melambangkan tanggal dan tahun bersejarah, yaitu Proklamasi Kemerdekaan Republik Indonesia serta menggambarkan tujuan untuk mewujudkan masyarakat adil dan makmur berdasarkan Pancasila.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Bulat Lonjong Merah dan Putih</span>&nbsp;bagi dua secara horizontal melambangkan bendera Negara Kesatuan Republik Indonesia.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Perisai Segi Lima</span>&nbsp;melambangkan Pancasila dasar negara Republik Indonesia.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Rumah Adat</span>&nbsp;melambangkan bahwa Kabupaten Toba merupakan suatu rumah tangga atau suatu daerah otonom yang mempunyai otonom atau hak dan kewajiban untuk mengatur dan mengurus rumah tangganya sendiri sesuai dengan Peraturan perundangan yang berlaku. Rumah tersebut mempunyai bentuk dan ciri sebagai berikut:\r\n<ul style=\"box-sizing: border-box; list-style: disc; padding: 0px 0px 0px 15px; margin-top: 0px; margin-bottom: 0px; margin-left: 15px;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Tiang Kiri Kanan</span>&nbsp;yang menandakan bahwa Pembentukan Kabupaten Toba ditetapkan dengan Undang-Undang nomor 12 Tahun 1998, anak tangga berjumlah lima tingkatan, rusuk tiang tiga dipadu dengan satu helai ulos, yang melengkung rumbai sembilan di kiri dan di kanan sisi bawah menandakan bahwa Kabupaten Toba diresmikan pada tanggal 9 Maret 1999 oleh Menteri Dalam Negeri atas nama Presiden Republik Indonesia bertempat di Kantor Gubernur Sumatera Utara di Medan.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Ransang</span>&nbsp;(rusuk tiang) terdiri dari tiga jalur melambangkan sistem kekerabatan Dalihan Na Tolu sebagai salah satu filosofi dalam budaya adat Batak Toba dan secara keseluruhan struktur rumah adat Batak melambangkan norma-norma kehidupan masyarakat Batak yang perlu untuk senantiasa dijaga, dipelihara, dilestarikan dan dikembangkan sesuai dengan kemajuan ilmu dan teknologi.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Rumah Adat dalam Perisai Segi Lima</span>&nbsp;dilatarbelakangi oleh lukisan &ndash; lukisan Bukit Barisan, Danau Toba dan Pulo Samosir menggambarkan bahwa di wilayah Kabupaten Toba terdapat berbagai potensi alam yang dapat dikembangkan untuk kemakmuran masyarakat.</li>\r\n</ul>\r\n</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Piso Halasan</span>&nbsp;menggambarkan bahwa Kabupaten Toba adalah termasuk lokasi perjuangan dan Tempat Makam Pahlawan Nasional Raja Sisingamangaraja XII.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Hutan dan Lahan Hijau</span>&nbsp;menggambarkan area pertanian yang subur.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Tungkot Balehat Raja</span>&nbsp;menggambarkan bahwa masyarakat Toba selalu menginginkan pemimpin yang bijaksana dan berwibawa.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Pustaha dan Sipun</span>&nbsp;melambangkan harapan untuk mewujudkan sumber daya manusia yang berkualitas melalui pendidikan sebagai wujud dari salah satu filosofi masyarakat Batak Toba, yaitu&nbsp;Anakhonhi do Hamoraon di Au.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Bendungan dan Busur/Air Terjun</span>&nbsp;adalah potensi alam yang telah diolah dan siap untuk dikembangkan menuju industri yang tepat guna.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Pita</span>&nbsp;tempat tulisan Toba berwarna kuning melambangkan masyarakat Toba senantiasa optimis untuk mencapai masyarakat adil dan makmur.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Motto (semboyan)</span>&nbsp;Kabupaten Toba dalam Bahasa Batak Toba disebut&nbsp;<span style=\"box-sizing: border-box; font-weight: bolder; color: #c1282a;\">Tampakna do rantosna, rim ni tahi do gogona.</span> Yang mengandung arti bahwa dengan persatuan dan kesatuan yang dilandasi rasa kebersamaan untuk bekerja sama untuk saling membantu, maka apa yang diharapkan akan selalu dapat dicapai.</li>\r\n</ol>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>', 1, '2022-12-06', '_self', '', '', '', '', 1, 0, 0),
(97, 0, 'SECTION_3', 'section3', '', '   <h2 class=\"mb-0\">\r\n          <span class=\"font-weight-semibold\">Agenda Penting Pemerintahan</span>\r\n        </h2>\r\n        <span class=\"font-weight-light\">Apa yang Terjadi Di Kabupaten Toba</span>  \r\n', 3, '2022-12-05', '', '', '', '', '', 1, 0, 0),
(98, 0, 'SECTION_4', 'section4', '', '       \r\n<section class=\"home-main-testimonial pt-12 pb-13\" id=\"section-04\">\r\n    <div class=\"container\">\r\n      <h2 class=\"mb-8\">\r\n        <span class=\"font-weight-semibold\">Selamat Datang Di Kabupaten Toba</span>\r\n      </h2>\r\n      <div class=\"container\">\r\n        <div class=\"row\">\r\n          <div class=\"col col-md-12\">\r\n            <div\r\n              class=\"slick-slider testimonials-slider arrow-top\"\r\n              data-slick-options=\'{literal}{\"slidesToShow\": 1,\"autoplay\":false,\"dots\":false,\"responsive\":[{\"breakpoint\": 992,\"settings\": {\"slidesToShow\": 1,\"arrows\":false}}]}{/literal}\'\r\n            >\r\n              <div class=\"box\">\r\n                <div\r\n                  class=\"card testimonial h-100 border-0 bg-transparent\"\r\n                >\r\n                  <div class=\"card-body bg-white\">\r\n                    <div class=\"testimonial-icon text-right\">\r\n                      <svg class=\"icon icon-quote\">\r\n                        <use xlink:href=\"#icon-quote\"></use>\r\n                      </svg>\r\n                    </div>\r\n                    <ul\r\n                      class=\"list-inline mb-4 d-flex align-items-end flex-wrap\"\r\n                    >\r\n                      <li class=\"list-inline-item\">\r\n                        <span\r\n                          class=\"font-size-lg text-dark font-weight-semibold d-inline-block\"\r\n                          >Dengan Kepribadian Batak Naraja:\r\n                        </span>\r\n                      </li>\r\n                    </ul>\r\n                    <div class=\"card-text text-gray pr-4\">\r\n                      <ul\r\n                      class=\"list-inline mb-4 flex-wrap\"\r\n                    >\r\n                      <li>\r\n                        <span\r\n                          class=\"text-dark font-weight-semibold\"\r\n                          ><i class=\"fas fa-check-circle text-danger\"></i> MARUGAMO : Marsihaholongan Jala Marsiurupan\r\n                        </span>\r\n                      </li>\r\n                      <li>\r\n                        <span\r\n                          class=\"text-dark font-weight-semibold\"\r\n                          ><i class=\"fas fa-check-circle text-danger\"></i> MARADAT : Manat, Elek Jala Somba\r\n                        </span>\r\n                      </li>\r\n                      <li>\r\n                        <span\r\n                          class=\"text-dark font-weight-semibold\"\r\n                          ><i class=\"fas fa-check-circle text-danger\"></i> MARUHUM : Ndang Pajolo Gogo, Papudi Uhum\r\n                        </span>\r\n                      </li>\r\n                      <li>\r\n                        <span\r\n                          class=\"text-dark font-weight-semibold\"\r\n                          ><i class=\"fas fa-check-circle text-danger\"></i> MARPARBINOTOAN : Marbisuk Jala Pistar\r\n                        </span>\r\n                      </li>\r\n                    </ul>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n', 3, '2022-12-05', '', '', '', '', '', 1, 0, 0),
(154, 0, 'SECTION_5', 'section5', '', ' <h2 class=\"mb-3 mb-sm-0\">\r\n          <span class=\"font-weight-semibold\">Berita Seputar</span>\r\n          <span class=\"font-weight-light\">Kabupaten Toba</span>\r\n        </h2>  \r\n', 3, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(157, 0, 'Festival Danau Toba', 'festival-danau-toba', '', 'Merupakan event yang telah dilaksanakan sejak 1970-an yang dulu dikenal dengan sebutan Pesta Danau Toba. Mempersatukan seluruh komponen masyarakat Sumatera Utara untuk berkontribusi meratakan kesejahteraan masyarakat melalui sektor pariwisata dan ekonomi kreatif.', 8, '2022-12-05', '', 'page_20221205080036902.jpg', '', '', '', 1, 0, 0),
(158, 0, 'Karnaval Pesona Danau Toba 2020', 'karnaval-pesona-danau-toba-2020', '', '<p>Kawasan wisata Danau Toba bakal menggelar Event yang meriah, yakni Karnaval Pesona Danau Toba 2020. Event yang berpusat di Kota Balige, Sumatera Utara Karnaval Pesona Danau Toba akan berlangsung pada 03-05 Juli mendatang.</p>\r\n\r\n<p>Karnaval Pesona Danau Toba merupakan Event tahunan Kabupaten Toba Samosir yang merujuk kepada Instruksi Presiden pada Karnaval Kemerdekaan Pesona Danau Toba 2016.</p>\r\n\r\n<p>Salah satu kegiatan yang selalu ditunggu-tunggu dalam Karnaval Pesona Danau Toba ialah parade kendaraan hias berwarna-warni yang akan wara-wiri di Kawasan Danau Toba. Selain itu akan ada peragaan pakaian adat dan perlombaan kuliner khas batak.</p>', 8, '2022-12-05', '', 'page_20221205080749980.png', '', '', '', 1, 0, 0),
(107, 106, 'Luas Wilayah Geografi', 'luas-wilayah-geografi', '', '<h2 class=\"mb-3\">Luas Wilayah dan Geografis Kabupaten Toba</h2>\r\n\r\n<table class=\"table table-bordered\">\r\n  <tbody>\r\n    <tr>\r\n      <th scope=\"row\">1</th>\r\n      <td>Letak Kabupaten Kota</td>\r\n      <td><ul><li>2Â° 03Â° - 2Â° 40Â° Lintang Utara</li><li>\r\n98Â° 56Â° - 99Â° 40Â° Bujur Timur</li></ul></td>\r\n    </tr>\r\n    <tr>\r\n      <th scope=\"row\">2</th>\r\n      <td>Luas Wilyah/Area Width</td>\r\n      <td>202 180 Ha</td>\r\n    </tr>\r\n    <tr>\r\n      <th scope=\"row\">3</th>\r\n      <td>Letak Diatas Permukaan Laut</td>\r\n      <td>900 - 1.200 m</td>\r\n    </tr>\r\n<tr>\r\n      <th scope=\"row\">4</th>\r\n      <td>Luas Hutan</td>\r\n      <td>109 626 Ha</td>\r\n    </tr>\r\n<tr>\r\n      <th scope=\"row\">5</th>\r\n      <td>Wilayah administrasi\r\n</td>\r\n<td>\r\n<ol type=\"a\"><li>Jumlah Kecamatan : 16 Kecamatan</li><li>Jumlah Desa : 231 Desa</li> <li>Jumlah Kelurahan: 13 Kelurahan</li></ol></td>\r\n    </tr>\r\n<tr>\r\n      <th scope=\"row\">6</th>\r\n      <td>Batas Wilayah\r\n</td>\r\n<td>\r\n<ol type=\"a\"><li>Sebelah Utara : Kabupaten Simalungun</li><li>Sebelah Selatan: Kabupaten Tapanuli Utara</li> <li>Sebelah Barat: Danau Toba Dan Kabupaten Samosir</li><li>Sebelah Timur: Kabupaten Labuhan Batu Dan Kabupaten Asahan</li></ol></td>\r\n    </tr>\r\n  </tbody>\r\n</table>', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(108, 106, 'Topografi', 'topografi', '', 'Kabupaten Toba memiliki luas wilayah 2.021.80 kmÂ²[4] atau 3,19% dari total luas Provinsi Sumatra Utara. Kabupaten Toba berada pada 2Â°03â€² â€“ 2Â°40â€² Lintang Utara dan 98Â°56â€² â€“ 99Â°40â€² Bujur Timur. Kabupaten Toba terletak pada wilayah dataran tinggi dengan ketinggian antara 900 â€“ 2.200 meter di atas permukaan laut, dengan topografi dan kontur tanah yang beraneka ragam, yaitu datar, landai, miring dan terjal. Struktur tanahnya labil dan terletak pada wilayah gempa tektonik dan vulkanik.\r\nKarena terletak dekat Garis Khatulistiwa, Kabupaten Toba tergolong ke dalam daerah beriklim tropis. Sebagaimana kabupaten lainnya di Indonesia, Kabupaten Toba mempunyai musim kemarau dan musim penghujan. Musim kemarau biasanya terjadi pada bulan Januari sampai dengan Juli dan musim penghujan biasanya terjadi pada bulan Agustus sampai dengan bulan Desember, diantara kedua musim itu terdapat musim pancaroba.', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(109, 106, 'Iklim dan Curah Hujan', 'iklim-dan-curah-hujan', '', 'Toba terletak pada garis khatulistiwa, dan tergolong pada iklim tropis basah dengan suhu berkisar antara 17Ëš C â€“ 29Ëš C dan rata-rata kelembaban udara 85.04 %. Rata-rata tinggi curah hujan setiap tahun sebesar 223 mm dengan jumlah hari hujan sebanyak 17 hari.', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(110, 106, 'Hidrologi', 'hidrologi', '', '<div class=\"text-center\">\r\n<h2>Hidrologi</h2>\r\n<p>Kabupaten Toba merupakan wilayah yang terdiri dari pegunungan dan memliliki potensi sumber daya air dengan keberadaan air permukaan seperti Danau Tiba, sungai dan mata air yang cukup banyak tersebar di seluruh wilayah Kabupaten Toba<p>\r\n</div>', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(111, 106, 'Demografi', 'demografi', '', '<div class=\"text-center\">\r\n<h2>Jumlah Penduduk Menurut Jenis Kelamin dan Menurut Kecamatan 2016</h2>\r\n\r\n<img src=\"https://tobakab.go.id/wp-content/uploads/2021/04/Demografi-1.png\" alt=\"Kabupaten Toba\" class=\"img-fluid\">\r\n</div>', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(112, 105, 'Visi dan Misi', 'visi-dan-misi', '', '<div class=\"row\">\r\n<div class=\"col-md-8\">\r\n<h2 class=\"text-primary\" data-animate=\"fadeInUp\">VISI</h2>\r\n<h5 class=\"mb-5\" data-animate=\"fadeInUp\">TOBA UNGGUL DAN BERSINAR<h5>\r\n<h2 class=\"text-primary\" data-animate=\"fadeInDown\">MISI</h2>\r\n<ol type=\"1\" data-animate=\"fadeInDown\">\r\n<li>Infrastruktur yang Bagus dan Merata</li>\r\n<li>Membangun Sumber Daya Manusia (SDM) yang Unggul dan Andal</li>\r\n<li>Membangun Pertanian dan Peternakan Makmur dan Sejahtera</li>\r\n<li>Kesehatan yang Prima dan Terjangkau</li>\r\n<li>Pariwisata Berkat dan Meriah</li>\r\n<li>Membangun Iman yang Terpelihara</li>\r\n<li>Menciptakan Stabilitas Keamanan dan Ketertiban</li>\r\n</ol>\r\n</div>\r\n<div class=\"col-md-4\" data-animate=\"fadeInLeft\"><img class=\"img-fluid\" alt=\"Kabupaten Toba\" src=\"https://tobakab.go.id/wp-content/uploads/2021/04/bupati-1-686x694.png\"></div>\r\n</div>', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0);
INSERT INTO `cppage` (`id`, `iTopMenu`, `vPageName`, `vPermalink`, `vURL`, `tContent`, `idCategory`, `dCreated`, `cURLTarget`, `lbPicture`, `vMetaTitle`, `vMetaDesc`, `vMetaKeyword`, `iShow`, `iUrutan`, `iDefault`) VALUES
(113, 105, 'Sejarah Daerah', 'sejarah-daerah', '', '<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Sejarah Kabupaten Toba</span>&nbsp;bermula dari era pra-kolonial hingga sekarang. Kabupaten Toba adalah sebuah&nbsp;kabupaten&nbsp;di Provinsi&nbsp;Sumatra Utara,&nbsp;Indonesia&nbsp;yang dibentuk pada tahun 1998 atas pemekaran daerah dari&nbsp;Kabupaten Tapanuli Utara. Kabupaten Toba yang dihuni oleh&nbsp;Suku Batak Toba&nbsp;telah melalui banyak perubahan dan perkembangan dalam sejarahnya.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Masa Pra-Kolonial</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Menurut sejarah leluhur serta mitologi penciptaan dan penyebaran orang Batak Toba di Tano Batak, Kabupaten Toba adalah salah satu wilayah perkembangan Suku Batak Toba. Dalam perkembangannya Suku Batak Toba dapat dikategorikan sebagai empat sub-suku yang memiliki wilayah masing-masing; dan dewasa ini status tiap wilayah sub-suku telah angkat menjadi kabupaten. Adapun keempat sub suku Batak Toba adalah:</p>\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Humbang, saat ini bagian dari Kabupaten Humbang Hasundutan</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Samosir, saat ini bagian dari Kabupaten Samosi</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Silindung, saat ini bagian dari Kabupaten Tapanuli Utara</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Toba Holbung, saat ini bagian dari Kabupaten Toba</li>\r\n</ol>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Kawasan Toba Holbung (atau sering disebut Toba saja) menjadi tanah ulayat para leluhur Suku Batak Toba ratusan tahun yang lalu, adapun&nbsp;Marga Batak&nbsp;yang&nbsp;bermukim di Toba Holbung&nbsp;dapat digolongkan kedalam empat kelompok, yaitu:</p>\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Marga keturunan&nbsp;Nai Rasaon(Butarbutar,&nbsp;Manurung,&nbsp;Sirait, dan&nbsp;Sitorus) menduduki wilayah utara (Kecamatan Ajibata, Lumban Julu, Porsea, Parmaksian, dan Uluan)</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Marga keturunan&nbsp;Sibagot Ni Pohan(Tampubolon,&nbsp;Barimbing,&nbsp;Silaen,&nbsp;Siahaan,&nbsp;Simanjuntak,&nbsp;Hutagaol,&nbsp;Panjaitan,&nbsp;Siagian,&nbsp;Pardosi,&nbsp;Sianipar,&nbsp;Simangunsong,&nbsp;Marpaung,&nbsp;Napitupulu, dan&nbsp;Pardede) menduduki wilayah selatan (Kecamatan Balige, Habinsaran, Siantar Narumonda, Sigumpar, Silaen, Tampahan)</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Marga keturunan&nbsp;Sipaet Tua(Aruan,&nbsp;Hutahaean,&nbsp;Hutajulu,&nbsp;Hutapea,&nbsp;Pangaribuan,&nbsp;Sibarani,&nbsp;Sibuea) menduduki wilayah selatan (Kecamatan Laguboti dan Silaen)</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Marga keturunan&nbsp;Borbor(Lubis,&nbsp;Pasaribu,&nbsp;Sipahutar,&nbsp;Tanjung) menduduki wilayah timur (Kecamatan Borbor, Laguboti, Habinsaran, dan Nassau)</li>\r\n</ol>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Hingga saat ini Kabupaten Toba masih didominasi oleh marga-marga tersebut.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Sebelum Kemerdekaan Indonesia</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada masa pemerintahan&nbsp;Hindia Belanda, Kabupaten Toba termasuk dalam&nbsp;Karesidenan Tapanuli&nbsp;yang dipimpin seorang Residen bangsa&nbsp;Belanda&nbsp;yang berkedudukan di&nbsp;Sibolga. Keresidenan Tapanuli yang dulu disebut Residentie Tapanuli terdiri dari empat&nbsp;<em style=\"box-sizing: border-box;\">Afdeling</em>&nbsp;(Kabupaten) yaitu:</p>\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Afdeling Batak Landen</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Afdeling Mandailing Angkola</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Afdeling Sibolga en Omstreken</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Afdeling Nias</li>\r\n</ol>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Afdeling Batak Landen dipimpin seorang Asisten Residen yang beribu kotakan&nbsp;Tarutung&nbsp;yang terdiri lima&nbsp;<em style=\"box-sizing: border-box;\">Onderafdeling</em>&nbsp;(wilayah) yaitu:</p>\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box;\">Onderafdeling Silindung</em>(Kabupaten Tapanuli Utara&nbsp;sekarang) dengan ibu kota&nbsp;Tarutung</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box;\">Onderafdeling Hoovlakte Van Toba</em>(Kabupaten Tapanuli Utara&nbsp;sekarang) dengan ibu kota&nbsp;Siborongborong</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box;\">Onderafdeling Toba</em>(Kabupaten Toba&nbsp;sekarang) dengan ibu kota&nbsp;Balige</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box;\">Onderafdeling Samosir</em>(Kabupaten Samosir&nbsp;sekarang) dengan ibu kota&nbsp;Pangururan</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box;\">Onderafdeling Dairi Landen</em>(Kabupaten Dairi&nbsp;sekarang) dengan ibu kota&nbsp;Sidikalang</li>\r\n</ol>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Tiap-tiap Onderafdeling mempuyai satu&nbsp;Distrik&nbsp;(kewedanaan) dipimpin seorang&nbsp;<em style=\"box-sizing: border-box;\">Distrikchoolfd</em>&nbsp;bangsa&nbsp;Indonesia&nbsp;yang disebut Demang dan membawahi beberapa&nbsp;<em style=\"box-sizing: border-box;\">Onderdistrikten</em>&nbsp;(kecamatan) yang dipimpin oleh seorang Asisten Demang.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Menjelang Perang Dunia II, distrik-distrik di seluruh keresidenan Tapanuli dihapuskan dan beberapa Demang yang mengepalai distrik-distrik sebelumnya diperbantukan ke kantor&nbsp;<em style=\"box-sizing: border-box;\">Controleur</em>&nbsp;masing-masing dan disebut namanya Demang&nbsp;<em style=\"box-sizing: border-box;\">Terbeschingking</em>. Dengan penghapusan ini para Asisten Demang yang ada di kantor Demang itu ditetapkan menjadi Asisten Demang di Onderdistrik bersangkutan.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Kemudian tiap Onderdistrik membawahi beberapa negeri yang dipimpin oleh seorang kepala Negeri yang disebut&nbsp;<em style=\"box-sizing: border-box;\">Negeri Hoofd</em>. Pada waktu berikutnya diubah dan dilaksanakan pemilihan, tetapi tetap memperhatikan asal usulnya. Negeri-negeri ini terdiri dari beberapa kampung, yang dipimpin seorang kepala kampung yang disebut&nbsp;<em style=\"box-sizing: border-box;\">Kampung Hoofd</em>&nbsp;dan juga diangkat serupa dengan pengangkatan&nbsp;<em style=\"box-sizing: border-box;\">Negeri Hoofd</em>. Negeri dan Kampung Hoofd statusnya bukan pegawai negeri, tetapi pejabat-pejabat yang berdiri sendiri di negeri/kampungnya. Mereka tidak menerima gaji dari pemerintah tetapi dari upah pungut pajak dan khusus&nbsp;<em style=\"box-sizing: border-box;\">Negeri Hoofd</em>&nbsp;menerima tiap-tiap tahun upah yang disebut&nbsp;<em style=\"box-sizing: border-box;\">Yoarliykse Begroting</em>.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Tugas utama Negeri dan&nbsp;<em style=\"box-sizing: border-box;\">Kampung Hoofd</em>&nbsp;ialah memelihara keamanan dan ketertiban, memungut pajak/blasting/rodi dari penduduk Negeri/Kampung masing-masing. Blasting/rodi ditetapkan tiap-tiap tahun oleh&nbsp;<em style=\"box-sizing: border-box;\">Kontraleur</em>&nbsp;sesudah panen padi.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada waktu pendudukan tentara Jepang Tahun&nbsp;1942-1945&nbsp;struktur pemerintahan di Tapanuli Utara hampir tidak berubah, hanya namanya yang berubah seperti:</p>\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Asistent Resident diganti dengan nama&nbsp;<em style=\"box-sizing: border-box;\">Gunseibu</em>dan menguasai seluruh tanah batak dan disebut&nbsp;<em style=\"box-sizing: border-box;\">Tanah Batak Sityotyo</em>.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Demang-demang Terbeschiking menjadi&nbsp;<em style=\"box-sizing: border-box;\">Guntyome</em>memimpin masing-masing wilayah yang disebut&nbsp;<em style=\"box-sizing: border-box;\">Gunyakusyo</em>.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Asisten Demang tetap berada di posnya masing-masing dengan nama&nbsp;<em style=\"box-sizing: border-box;\">Huku Guntyo</em>dan kecamatannya diganti dengan nama&nbsp;<em style=\"box-sizing: border-box;\">Huku Gunyakusyo</em>.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Negeri dan Kampung Hoofd tetap memimpin Negeri/Kampungnya masing-masing dengan mengubah namanya menjadi Kepala Negeri dan Kepala kampung.</li>\r\n</ol>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Masa Pemerintahan Republik Indonesia</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Sesudah&nbsp;kemerdekaan Republik Indonesia&nbsp;diproklamasikan tanggal 17 Agustus 1945, pemerintah mulai membentuk struktur pemerintahan baik di pusat dan di daerah. Dengan diangkatnya&nbsp;Dr. Ferdinand Lumbantobing&nbsp;sebagai Residen Tapanuli, disusunlah struktur pemerintahan dalam negeri di Tapanuli khususnya di Tapanuli Utara sebagai berikut:</p>\r\n<ol style=\"box-sizing: border-box; padding-left: 2rem; margin-top: 0px; margin-bottom: 1rem; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Nama&nbsp;<em style=\"box-sizing: border-box;\">Afdeling Batak Landen</em>diganti menjadi Luhak Tanah batak dan sebagai luhak pertama diangkat&nbsp;Cornelis Sihombing.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Nama&nbsp;<em style=\"box-sizing: border-box;\">Budrafdeling</em>diganti menjadi Urung dipimpin Kepala Urung, Para Demang memimpin Onderafdeling sebagai Kepala Urung.</li>\r\n<li style=\"box-sizing: border-box; margin-bottom: 0px;\">Nama&nbsp;<em style=\"box-sizing: border-box;\">Onderdistrik</em>diganti menjadi Urung kecil dan dipimpin Kepala Urung Kecil yang dulu disebut Asisten Demang.</li>\r\n</ol>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Selanjutnya dalam waktu tidak begitu lama terjadi perubahan, nama Luhak diganti menjadi&nbsp;kabupaten&nbsp;yang dipimpin Bupati, Urung menjadi Wilayah yang dipimpin Demang, serta Urung Kecil menjadi&nbsp;kecamatan&nbsp;yang dipimpin oleh Asisten Demang.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada tahun 1946 Kabupaten Tanah Batak terdiri dari 5 (lima) wilayah yaitu Wilayah Silindung, Wilayah Humbang, Wilayah Toba, Wilayah Samosir dan Wilayah Dairi yang masing-masing dipimpin oleh seorang Demang. Kecamatan-kecamatan tetap seperti yang ditinggalkan Jepang. Pada Tahun 1947 terjadi Agresi I oleh Belanda di mana Belanda mulai menduduki daerah Sumatra Timur maka berdasarkan pertimbangan-pertimbangan strategis dan untuk memperkuat pemerintahan dan pertahanan, Kabupaten Tanah Batak dibagi menjadi 4 (empat) kabupaten. Wilayah menjadi kabupaten dan memperbanyak kecamatan. Pada tahun 1948 terjadi Agresi II oleh Belanda, untuk mempermudah hubungan sipil dan Tentara Republik, maka pejabat-pejabat Pemerintahan Sipil dimiliterkan dengan jabatan Bupati Militer, Wedana Militer dan Camat Militer. Untuk mempercepat hubungan dengan rakyat, kewedanaan dihapuskan dan para camat langsung secara administratif ke Bupati.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Setelah Belanda meninggalkan Indonesia pada pengesahan kedaulatan, pada permulaan tahun 1950 di Tapanuli dibentuk Kabupaten baru yaitu&nbsp;Kabupaten Tapanuli Utara&nbsp;(dulu Kabupaten Batak),&nbsp;Kabupaten Tapanuli Selatan&nbsp;(dulu Kabupaten Padang Sidempuan),&nbsp;Kabupaten Tapanuli Tengah&nbsp;(dulu Kabupaten Sibolga) dan&nbsp;Kabupaten Nias. Dengan terbentuknya kabupaten ini, maka kabupaten-kabupaten yang dibentuk pada tahun 1947 dibubarkan. Di samping itu di setiap kabupaten dibentuk badan legislatif Dewan Perwakilan Rakyat Sementara yang anggotanya dari anggota partai politik setempat. Mengingat luasnya wilayah Kabupaten Tapanuli Utara meliputi Dairi pada waktu itu, maka untuk meningkatkan daya guna pemerintahan, pada tahun&nbsp;1956&nbsp;dibentuk&nbsp;Kabupaten Dairi&nbsp;yang terpisah dari Kabupaten Tapanuli Utara.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Pembentukan Kabupaten Toba</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Kabupaten Toba dimekarkan dari&nbsp;Kabupaten Daerah Tingkat II Tapanuli Utara&nbsp;setelah menjalani waktu yang cukup lama dan melewati berbagai proses, pada akhirnya terwujud menjadi kabupaten baru dengan Undang &ndash; Undang Nomor 12 Tahun 1998 tentang Pembentukan Kabupaten DATI II Toba dan Kabupaten DATI II Mandailing Natal di Daerah Tingkat I&nbsp;Sumatra Utara. Kabupaten Toba diresmikan pada tanggal 9&nbsp;Maret&nbsp;1999&nbsp;bertempat di Kantor&nbsp;Gubernur&nbsp;Sumatra Utara&nbsp;oleh Menteri Dalam Negeri&nbsp;Syarwan Hamid&nbsp;atas nama&nbsp;Presiden&nbsp;Republik Indonesia&nbsp;sekaligus melantik Drs. Sahala Tampubolon selaku Penjabat&nbsp;Bupati&nbsp;Toba. Pada saat itu, sebagai Sekretaris Daerah Kabupaten adalah Drs. Parlindungan Simbolon.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Setelah Kabupaten Toba diresmikan, diangkat Ketua&nbsp;DPRD&nbsp;Sementara adalah M.P. Situmorang, selanjutnya dilakukan pemilihan yang hasilnya adalah Ketua Drh. Unggul Siahaan dan Wakil Ketua M.A. Simanjuntak dan Wakil Ketua Drs. L.P. Sitanggang. Pada tahun&nbsp;1999, dilaksanakan pemilihan umum di Indonesia, dengan hasil menetapkan 35 anggota DPRD Kabupaten Toba, serta menetapkan pimpinan&nbsp;DPRD&nbsp;Kabupaten Toba masa bakti&nbsp;1999&nbsp;&ndash;&nbsp;2004&nbsp;yaitu: Ketua Ir. Bona Tua Sinaga dan Wakil Ketua masing &ndash; masing adalah Sabam Simanjuntak, Drs. Vespasianus Panjaitan dan Letkol W. Nainggolan. Pada tahun&nbsp;2000&nbsp;diadakan pemilihan Bupati dan Wakil Bupati Toba, dengan hasil pemilihan, menetapkan Drs. Sahala Tampubolon sebagai Bupati dan Maripul S. Manurung, SH., sebagai wakil Bupati Toba, masa bakti 2000 &ndash; 2005, pelantikan dilaksanakan pada tanggal 27 Juni 2000 di&nbsp;Balige.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada awal pembentukannya,&nbsp;kabupaten&nbsp;ini terdiri atas 13 (tiga belas)&nbsp;kecamatan, 5 (lima) kecamatan pembantu, 281&nbsp;desa&nbsp;dan 19&nbsp;kelurahan. Seiring dengan perjalanan pemerintahan di kabupaten ini jumlah kecamatan mengalami perubahan secara bertahap. Pada awal tahun&nbsp;2002&nbsp;dibentuk 5&nbsp;kecamatan&nbsp;baru yakni pendefinitifan 4 (empat) kecamatan pembantu mejadi 4 (empat) kecamatan defenitif dan pembentukan 1 (satu) kecamatan baru. Kelima kecamatan tersebut adalah&nbsp;Kecamatan Ajibata,&nbsp;Kecamatan Pintu Pohan Meranti,&nbsp;Kecamatan Uluan,&nbsp;Kecamatan Ronggur Nihuta&nbsp;dan&nbsp;Kecamatan Borbor.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Kondisi pemekaran kecamatan berlanjut hingga pada akhir tahun&nbsp;2002, dimana adanya aspirasi masyarakat yang cukup kuat dalam menyuarakan pemekaran Kecamatan Harian menjadi dua kecamatan yakni&nbsp;Kecamatan Harian&nbsp;dan&nbsp;Kecamatan Sitiotio&nbsp;sebagai kecamatan pemekaran baru. Kuatnya aspirasi pembentukan kecamatan ini disikapi dengan baik oleh Pemerintah Kabupaten Toba karena didukung fakta &ndash; fakta permasalahan di masyarakat baik kondisi geografis wilayah dan lain sebagainya, hingga akhirnya Pemerintah Kabupaten Toba menetapkan Keputusan Bupati Toba tentang Pembentukan Kecamatan Sitiotio mendahului Peraturan Daerah, setelah mendapatkan izin prinsip dari DPRD Kabupaten Toba pada tahun 2002. Keputusan Bupati ini dikuatkan dengan penetapan Peraturan Daerah Nomor 13 Tahun 2003 tentang Pembentukan Kecamatan Sitiotio di Kabupaten Toba.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Kabupaten Samosir dimekarkan dari Toba</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Perkembangan dan pembentukan wilayah tidak sampai disini saja, perubahan &ndash; perubahan lain semakin banyak terjadi seperti isu pemekaran kembali Kabupaten Toba menjadi 2 (dua)&nbsp;kabupaten. Isu ini berkembang seiring dengan situasi dan kondisi sosial, ekonomi dan politik yang berkembang pada saat itu. Perkembangan kondisi sosial, ekonomi, dan politik dimasyarakat menginginkan Kabupaten Toba dimekarkan kembali menjadi Kabupaten Toba dan&nbsp;Kabupaten Samosir&nbsp;(meliputi seluruh kecamatan yang ada di Pulau Samosir dan sebagian pinggiran&nbsp;Danau Toba&nbsp;di Daratan Pulau Sumatra) dengan tujuan untuk mempercepat pembangunan guna mengejar ketertinggalan dari daerah lain. Aspirasi yang berkembang di masyarakat ini tidak menunggu waktu yang begitu lama, hingga pada tahun&nbsp;2003&nbsp;Kabupaten Toba dimekarkan menjadi Kabupaten Toba dan&nbsp;Kabupaten Samosir&nbsp;yang ditetapkan dengan Undang &ndash; Undang Nomor 36 Tahun 2003 tentang Pembentukan Kabupaten Samosir dan&nbsp;Kabupaten Serdang Bedagai&nbsp;di Provinsi Sumatra Utara dan diresmikan pada tanggal 7 Januari&nbsp;2004.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Sejak peresmian ini, wilayah Kabupaten Toba berkurang karena seluruh wilayah kecamatan yang ada di Pulau Samosir dan sekitarnya sebagaimana diatur dalam Undang &ndash; Undang Nomor 36 Tahun 2003 tersebut masuk menjadi&nbsp;Kabupaten Samosir. Dan sejak tanggal 7 Januari 2004, Kabupaten Toba dari 20 Kecamatan, 281 Desa dan 19 Kelurahan mengalami perubahan baik jumlah kecamatan, desa dan kelurahan, jumlah penduduk, luas wilayah, dan batas &ndash; batas wilayah secara signifikan yakni menjadi 11 Kecamatan 179 Desa dan 13 Kelurahan. Sedangkan Kabupaten Samosir terdiri dari 9 Kecamatan, 102 Desa dan 6 Kelurahan.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Pemekaran Kecamatan di Kabupaten Toba</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pemekaran wilayah selanjutnya terjadi pada Kecamatan Silaen dengan melahirkan Kecamatan Sigumpar sesuai Peraturan Daerah Nomor 6 Tahun 2004. Banyak alasan yang mempengaruhi terjadinya pemekaran wilayah kecamatan di Kabupaten Toba, antara lain: kondisi luas wilayah, jarak ke ibu kota kabupaten, letak geografis, dikaitkan juga dengan kondisi ketertinggalan dan dorongan keinginan serta tuntutan masyarakat itu sendiri. Ada beberapa hal yang memperlihatkan kuatnya keinginan dan aspirasi masyarakat untuk maju, antara lain terlihat pada masyarakat Kecamatan Borbor dimana permintaan pemekaran diikuti dengan penyerahan lahan lokasi perkantoran dan penyediaan sarana gedung kantor kecamatan baru secara swadaya oleh masyarakat. Kondisi ini dinilai pemerintah sebagai bukti kesungguhan masyarakat yang mendambakan wilayahnya dimekarkan menjadi kecamatan baru.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\"><span style=\"box-sizing: border-box; font-weight: 600;\">Kondisi Saat Ini</span></p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada tahun 2004 dilaksanakan&nbsp;Pemilihan umum&nbsp;Legislatif yang menetapkan 25 anggota&nbsp;DPRD&nbsp;Kabupaten Toba.&nbsp;DPRD&nbsp;kemudian memilih pimpinan masa bakti 2004 &ndash; 2009 yaitu: Ketua Tumpal Sitorus, Wakil Ketua masing &ndash; masing adalah: Ir. Firman Pasaribu, dan Bachtiar Tampubolon, MBA. Pada tanggal 27 Juni 2005 KPUD Kabupaten Toba menyelenggarakan Pemilihan Kepala Daerah secara langsung sesuai dengan Undang &ndash; Undang Nomor: 32 Tahun 2004, namun untuk kelancaran pelaksanaan tugas &ndash; tugas pemerintahan di Kabupaten Toba sebelum terpilihnya Kepala Daerah, melalui Keputusan Menteri Dalam Negeri No. 131.22-463 Tahun 2005 tanggal 30 Juni 2005 diangkat Drs. Mangasi Lumbanraja sebagai Penjabat Bupati Toba yang pelantikannya dilaksanakan pada tanggal 07 Juli 2005. Dengan terpilihnya Bupati / Wakil Bupati melalui pemilihan kepala daerah maka pada tanggal 12 Agustus 2005 jabatan kepala daerah diserahkan kepada Bupati terpilih.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Dari hasil pemungutan suara yang diperoleh, KPUD Toba menetapkan pemenang Drs. Monang Sitorus, SH., MBA dan Ir. Mindo Tua Siagian, M.Sc sebagai Bupati dan Wakil Bupati Toba masa bakti 2005 &ndash; 2010. Pelantikan dilaksanakan pada tanggal 12 Agustus 2005 di Gedung DPRD Kabupaten Toba oleh Gubernur&nbsp;Sumatra Utara&nbsp;T. Rizal Nurdin&nbsp;(Alm). Sebagai Sekretaris Daerah pada waktu itu dijabat Drs. Tonggo Napitupulu, M.Si dan pada akhir tahun&nbsp;2005&nbsp;sampai dengan&nbsp;Agustus&nbsp;2009&nbsp;dijabat oleh Liberty Pasaribu, SH, M.Si. Sejalan dengan terpilihnya Bupati dan Wakil Bupati Toba periode 2005 &ndash; 2010, maka ditetapkan Visi Kabupaten Toba: &ldquo;Menjadi Kabupaten Terdepan, Makmur, Adil dan Sejahtera di Sumatra Utara Tahun 2010 (TOBAMAS 2010)&rdquo;.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada tahun 2006 Pemerintah Kabupaten Toba melaksanakan pemekaran kecamatan. Dari 11 kecamatan, dimekarkan kecamatan baru yakni&nbsp;Kecamatan Tampahan&nbsp;pemekaran dari&nbsp;Kecamatan Balige,&nbsp;Kecamatan Siantar Narumonda&nbsp;pemekaran dari&nbsp;Kecamatan Porsea, dan&nbsp;Kecamatan Nassau&nbsp;pemekaran dari&nbsp;Kecamatan Habinsaran. Pemekaran ketiga kecamatan baru tersebut ditetapkan dengan Peraturan Daerah Kabupaten Toba Nomor 17 Tahun 2006 tentang Pembentukan Kecamatan Siantar Narumonda, Kecamatan Nassau, Kecamatan Tampahan.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada tahun 2008 juga terjadi pemekaran kecamatan karena tingginya aspirasi masyarakat dalam pemerataan pembangunan. Adapun kecamatan yang dimekarkan adalah&nbsp;Kecamatan Parmaksian&nbsp;pemekaran dari&nbsp;Kecamatan Porsea&nbsp;dan&nbsp;Kecamatan Bonatua Lunasi&nbsp;pemekaran dari&nbsp;Kecamatan Lumban Julu&nbsp;yang ditetapkan dengan Peraturan Daerah Nomor: 05 Tahun 2008 tentang Pembentukan Kecamatan Parmaksian dan Kecamatan Bonatua Lunasi Kabupaten Toba. Pada tahun 2008 juga telah dilakukan pemekaran desa sebanyak dua puluh empat desa.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Kemudian pada tahun 2008 terjadi PAW DPRD untuk mengganti Ketua DPRD Kabupaten Toba pada tanggal 15 Desember 2008, terpilih Mangatas Silaen sebagai Ketua DPRD Kabupaten Toba yang baru sisa masa bakti 2004 &ndash; 2009. Pada tahun 2009 telah ditetapkan pembentukan dua puluh delapan desa, sehingga pada saat ini wilayah administrasi pemerintahan Kabupaten Toba terdiri dari enam belas kecamatan, tiga belas kelurahan dan dua ratus tiga puluh satu desa. Pada tanggal 9 April 2009 telah dilaksanakan Pemilu Legislatif dan di Kabupaten Toba menghasilkan 25 Anggota&nbsp;DPRD&nbsp;Kabupaten Toba yang dilantik pada tanggal 15 Desember 2009 dengan menetapkan pimpinan&nbsp;DPRD&nbsp;sementara yakni Sahat Panjaitan sebagai Ketua, Djojor Tambunan dan Rahmat Kurniawan Manullang sebagai Wakil Ketua dan pada tanggal 3 Maret 2010 yang lalu telah ditetapkan menjadi Pimpinan DRPD Kabupaten Toba defenitif untuk Periode Masa Jabatan 2009 &ndash; 2014 dengan Keputusan&nbsp;Gubernur&nbsp;Sumatra Utara&nbsp;Nomor: 188.44/93/KPTS/2010 tentang Peresmian Pengangkatan Pimpinan DPRD Kabupaten Toba Masa Jabatan 2009 &ndash; 2014.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 1rem; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Pada tanggal 12 Mei 2010 Kabupaten Toba melaksanakan Pemilihan Kepala Daerah dan Wakil Kepala Daerah Kabupaten Toba untuk masa jabatan 2010 &ndash; 2015. Dalam Pemilukada yang dilaksanakan secara demokratis tersebut pasangan Pandapotan Kasmin Simanjuntak dan Liberty Pasaribu, SH., M.Si., berhasil meraih suara terbanyak dan memenangkan Pemilukada tersebut. Selanjutnya pada tanggal 12 Agustus 2010, dengan Keputusan Menteri Dalam Negeri Republik Indonesia Nomor 131.12.278 Tahun 2010 tentang Pengesahan Pemberhentian dan Pengesahan Pengangkatan Bupati Toba Provinsi Sumatra Utara dan Keputusan Menteri Dalam Negeri Republik Indonesia Nomor 132.12.278 Tahun 2010 tentang Pengesahan Pemberhentian dan Pengesahan Pengangkatan Wakil Bupati Toba Provinsi Sumatra Utara yaitu pasangan Bupati dan Wakil Bupati Toba Bapak Pandapotan Kasmin Simanjuntak dan Liberty Pasaribu, SH., M.Si., dilantik oleh Gubernur Sumatra Utara Bapak H. Syamsul Arifin, SE melalui Rapat Paripurna Istimewa DPRD yang bertempat di Gedung DPRD Kabupaten Toba &ndash; Balige.</p>\r\n<p style=\"box-sizing: border-box; margin-bottom: 0px; margin-top: 0px; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">Sejalan dengan dilantiknya Bupati dan Wakil Bupati Toba, Bapak Pandapotan Kasmin Simanjuntak dan Liberty Pasaribu, SH., M.Si., untuk melaksanakan Visi Pemerintah Kabupaten Toba lima tahun ke depan yaitu: &ldquo;Terwujudnya Masyarakat Kabupaten Toba yang memiliki rasa Kasih, Peduli, dan Bermartabat&rdquo; sebagaimana telah ditetapkan dengan Peraturan Daerah Nomor 3 Tahun 2010 tentang Rencana Pembangunan Jangka Menegah Daerah (RPJMD) Kabupaten Toba Tahun 2011 &ndash; 2015.</p>', 1, '2022-12-05', '_self', '', '', '', '', 1, 0, 0),
(114, 105, 'Peta Toba', 'peta-toba', '', '<div class=\"row\">\r\n    <div class=\"col-md-4\">\r\n        <img src=\"https://tobakab.go.id/wp-content/uploads/2021/04/1200px-Peta_Wilayah_Kabupaten_Toba_Samosir.svg-e1618375743155.png\" alt=\"Kabupaten Toba\" class=\"img-fluid\">\r\n    </div>\r\n    <div class=\"col-md-8\">\r\n        <div class=\"widget map mb-6 position-relative mb-6 rounded-0\">\r\n            <div id=\"googleMap\" data-latlng=\"2.334655177090961, 99.0832519485498\" data-google-map=\"true\" class=\"small-map\" style=\"width:100%;height:240px;\"></div>\r\n            <div class=\"card p-4 widget border-0 infomation pt-0 bg-gray-06\">\r\n              <div class=\"card-body px-0 py-2\">\r\n                <ul class=\"list-group list-group-flush\">\r\n                  <li class=\"list-group-item bg-transparent d-flex text-dark px-0\">\r\n                    <span class=\"item-icon mr-3\"><i class=\"fal fa-map-marker-alt\"></i></span>\r\n                    <span class=\"card-text\">Kabupaten Toba</span>\r\n                  </li>\r\n                </ul>\r\n              </div>\r\n            </div>\r\n          </div>\r\n    </div>\r\n</div>', 1, '2022-12-06', '_self', '', '', '', '', 1, 0, 0),
(115, 105, 'Foto Kepala Daerah', 'foto-kepala-daerah', '', '\r\n<div class=\"row\">\r\n    <div class=\"col-md-6\">\r\n        <img src=\"https://tobakab.go.id/wp-content/uploads/2021/04/bupati-Toba.jpg\" alt=\"Kabupaten Toba\" class=\"img-fluid\">\r\n    </div>\r\n    <div class=\"col-md-6\">\r\n        <img src=\"https://tobakab.go.id/wp-content/uploads/2021/04/wabup-toba.jpg\" alt=\"Kabupaten Toba\" class=\"img-fluid\">\r\n    </div>\r\n</div>', 1, '2022-12-06', '_self', '', '', '', '', 1, 0, 0),
(106, 105, 'Sekilas Daerah', 'sekilas-daerah', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(105, 0, 'Profil', 'profil', '', '', 1, '2022-11-09', '_self', '', '', '', '', 1, 0, 0),
(134, 0, 'JDIH', 'jdih', '', 'Jaringan Documentasi Dan Jariang Hukum', 7, '2022-11-15', '_self', 'page_20221115061136225.svg', '', '', '', 1, 0, 0),
(132, 0, 'Home', 'home', '#', 'Portal Utama Kabupate Toba', 7, '2022-11-15', '_self', 'page_20221115060623866.svg', '', '', '', 1, 0, 0),
(133, 0, 'Kawal covid', 'kawal-covid', '#', 'Peta Sebaran COVID-19 Kabupaten Toba', 7, '2022-11-15', '_self', 'page_20221115061051605.svg', '', '', '', 1, 0, 0),
(135, 0, 'JDIH DPRD', 'jdih-dprd', '', 'Jaringan Documentasi Dan Jariang Hukum DPRD', 7, '2022-11-15', '_self', 'page_20221115061158872.svg', '', '', '', 1, 0, 0),
(136, 0, 'E-Pegawai', 'e-pegawai', '', 'E-Pegawai Kabupaten Toba', 7, '2022-11-15', '_self', 'page_20221115061229493.svg', '', '', '', 1, 0, 0),
(137, 0, 'E-Keuangan', 'e-keuangan', '', 'E-Budgeting Kabupaten Toba\r\n', 7, '2022-11-15', '_self', 'page_20221115061308144.svg', '', '', '', 1, 0, 0),
(138, 0, 'E-Perencanaan', 'e-perencanaan', '#', 'E-Planning Pemerintahah Kabupaten Toba', 7, '2022-11-15', '_self', 'page_20221115061427623.svg', '', '', '', 1, 0, 0),
(139, 0, 'E-LPPD', 'e-lppd', '', 'E-LPPD Kabupaten Toba', 7, '2022-11-15', '_self', 'page_20221115061520437.svg', '', '', '', 1, 0, 0),
(140, 0, 'LAPOR ', 'lapor-', 'https://www.lapor.go.id', 'Layanan Aspirasi dan Pengaduan Online', 7, '2022-11-15', '_self', 'page_20221115061650879.svg', '', '', '', 1, 0, 0),
(141, 0, 'Website OPD', 'website-opd', '', 'Organisasi Perangkat Daerah', 7, '2022-11-15', '_self', 'page_20221115061759236.svg', '', '', '', 1, 0, 0),
(142, 0, 'DEKRANASDA', 'dekranasda', '#', 'Dewan Kerajianan Nasional Daerah', 7, '2022-11-15', '_self', 'page_20221115061919937.svg', '', '', '', 1, 0, 0),
(143, 0, 'PRP2', 'prp2', '#', 'Progress Report Pengendalian Pembangunan', 7, '2022-11-15', '_blank', 'page_20221115062439808.svg', '', '', '', 1, 0, 0),
(144, 0, 'Webmail', 'webmail', '', 'Webmail', 7, '2022-11-15', '_self', 'page_20221115070533815.svg', '', '', '', 1, 0, 0),
(145, 0, 'RSUD', 'rsud', 'https://rsudporsea.tobakab.go.id', 'Rumah Sakit Umum Dearah Porsea', 7, '2022-11-15', '_blank', 'page_20221115070642226.svg', '', '', '', 1, 0, 0),
(146, 0, 'TP PKK', 'tp-pkk', '#', 'Pemberdayaan Kesejahteraan Keluarga', 7, '2022-11-15', '_self', 'page_20221115070754533.svg', '', '', '', 1, 0, 0),
(147, 0, 'E-Dasawisma', 'e-dasawisma', '#', 'E-Dasawisma Kabupaten Toba', 7, '2022-11-15', '_self', 'page_20221115070844349.png', '', '', '', 1, 0, 0),
(148, 0, 'LPSE', 'lpse', '#', 'Sistem Pengadaan Secara Elektronik', 7, '2022-11-15', '_self', 'page_20221115070939008.png', '', '', '', 1, 0, 0),
(149, 0, 'SICANTIK', 'sicantik', '#', 'Penanaman Modal dan Perizinan Terpadu', 7, '2022-11-15', '_self', 'page_20221115071048782.png', '', '', '', 1, 0, 0),
(150, 0, 'Desa', 'desa', '#', 'Desa Kabupaten Toba', 7, '2022-11-16', '_self', 'page_20221116065347702.png', '', '', '', 1, 0, 0),
(151, 150, 'Desa Meat', 'desa-meat', '', '', 7, '2022-11-16', '_self', 'page_20221115071502130.png', '', '', '', 1, 0, 0),
(153, 0, 'Soposurung Art Festival', 'soposurung-art-festival', '', '<p>Soposurung Art Festival sebagai bagian dari Calender of Event Pariwisata Danau Toba merupakan kegiatan yang dikemas dalam bentuk event festival seni dan budaya masyarakat setempat. Event ini menampilkan berbagai seni tari maupun seni suara dan budaya yang berkembang di masyarakat yang ada di Soposurung. Meskipun Festival ini masih belum dikenal oleh masyarakat luas, namun diharapkan melalui kegiatan yang konsisten seperti ini dapat menjadi bagian dari pesona indonesia yang hadir di bumi pertiwi sebagai warisan budaya yang utuh dan lestari. </p>', 8, '2022-12-05', '', 'page_20221204111731338.jpg', '', '', '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cppagecategory`
--

CREATE TABLE `cppagecategory` (
  `id` int(10) NOT NULL,
  `vCategory` varchar(50) DEFAULT NULL,
  `iAddPage` int(1) DEFAULT '0',
  `iPictureIcon` int(1) DEFAULT '0',
  `iContent` int(1) DEFAULT '0',
  `iMenuURL` int(1) DEFAULT '0',
  `iLinkTarget` int(1) DEFAULT '0',
  `iEditor` int(1) DEFAULT '0',
  `iModule` int(1) NOT NULL DEFAULT '0',
  `iMeta` int(1) NOT NULL DEFAULT '0',
  `iLiveEditor` int(1) NOT NULL DEFAULT '0',
  `iOpsi` int(1) NOT NULL DEFAULT '0',
  `vPermalink` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cppagecategory`
--

INSERT INTO `cppagecategory` (`id`, `vCategory`, `iAddPage`, `iPictureIcon`, `iContent`, `iMenuURL`, `iLinkTarget`, `iEditor`, `iModule`, `iMeta`, `iLiveEditor`, `iOpsi`, `vPermalink`) VALUES
(1, 'TOPMENU', 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 'topmenu'),
(3, 'OPTIONAL', 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 'optional'),
(7, 'HOME', 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 'home'),
(8, 'EVENT', 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 'event');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cppageconf`
--

CREATE TABLE `cppageconf` (
  `id` int(10) NOT NULL,
  `idPage` int(10) DEFAULT '0',
  `iAddPage` int(1) DEFAULT '0',
  `iPictureIcon` int(1) DEFAULT '0',
  `iContent` int(1) DEFAULT '0',
  `iMenuURL` int(1) DEFAULT '0',
  `iLinkTarget` int(1) DEFAULT '0',
  `iEditor` int(1) DEFAULT '0',
  `iModule` int(1) NOT NULL DEFAULT '0',
  `iMeta` int(1) NOT NULL DEFAULT '0',
  `iLiveEditor` int(1) NOT NULL DEFAULT '0',
  `iOpsi` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cppageconf`
--

INSERT INTO `cppageconf` (`id`, `idPage`, `iAddPage`, `iPictureIcon`, `iContent`, `iMenuURL`, `iLinkTarget`, `iEditor`, `iModule`, `iMeta`, `iLiveEditor`, `iOpsi`) VALUES
(15, 15, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(27, 27, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(4, 4, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(5, 5, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(90, 90, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0),
(91, 91, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(9, 9, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 10, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0),
(42, 42, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(13, 13, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0),
(41, 41, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(18, 18, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(24, 24, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(23, 23, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(25, 25, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(26, 26, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(28, 28, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(29, 29, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1),
(30, 30, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(31, 31, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(32, 32, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(33, 33, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(34, 34, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(35, 35, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(36, 36, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(37, 37, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(38, 38, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(39, 39, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(40, 40, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(43, 43, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(52, 52, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(45, 45, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(46, 46, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(49, 49, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(50, 50, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(51, 51, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(53, 53, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(54, 54, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(55, 55, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(56, 56, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(57, 57, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(58, 58, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(59, 59, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(60, 60, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(61, 61, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(62, 62, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(63, 63, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(64, 64, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(65, 65, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(66, 66, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(67, 67, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(68, 68, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(69, 69, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(70, 70, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(71, 71, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(72, 72, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(73, 73, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(74, 74, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(75, 75, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(76, 76, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(77, 77, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(78, 78, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(79, 79, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(80, 80, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(81, 81, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(82, 82, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(83, 83, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(84, 84, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(85, 85, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(86, 86, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(87, 87, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(88, 88, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(89, 89, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(92, 92, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0),
(155, 155, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(97, 97, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(98, 98, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(158, 158, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0),
(157, 157, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0),
(154, 154, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(102, 102, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(103, 103, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(104, 104, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(105, 105, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(106, 106, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(107, 107, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(108, 108, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0),
(109, 109, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0),
(110, 110, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(111, 111, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(112, 112, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(113, 113, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0),
(114, 114, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(115, 115, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(116, 116, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0),
(117, 117, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(118, 118, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(119, 119, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(120, 120, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0),
(121, 121, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(122, 122, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(123, 123, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(124, 124, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(125, 125, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0),
(126, 126, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(127, 127, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0),
(133, 133, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(132, 132, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(134, 134, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(135, 135, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(136, 136, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(137, 137, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(138, 138, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(139, 139, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(140, 140, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(141, 141, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(142, 142, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(143, 143, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(144, 144, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(145, 145, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(146, 146, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(147, 147, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(148, 148, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(149, 149, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(150, 150, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(151, 151, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(153, 153, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpphoto`
--

CREATE TABLE `cpphoto` (
  `id` int(10) NOT NULL,
  `idAlbum` int(10) DEFAULT '0',
  `vPhotoTitle` varchar(100) DEFAULT '',
  `vPermalink` varchar(100) DEFAULT NULL,
  `mtDesc` text,
  `vPhotoName` varchar(40) DEFAULT '',
  `dPublishDate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpphoto`
--

INSERT INTO `cpphoto` (`id`, `idAlbum`, `vPhotoTitle`, `vPermalink`, `mtDesc`, `vPhotoName`, `dPublishDate`) VALUES
(1, 1, 'Test Photo Pertama', 'test', 'Testttt', 'photo_2022222094800472.jpg', '2022-02-22'),
(8, 2, 'No Caption', 'photo-20221205210536', 'No Description', 'photo_20221205090536457.png', '2022-12-05'),
(6, 1, 'Photo Ketiga A', 'photo-ketiga', 'Photo Ketiga', 'photo_2022222100942943.png', '2022-02-22'),
(7, 5, 'Contoh Foto', 'contoh-foto', 'Contoh Foto', 'photo_2022224074030296.jpg', '2022-02-24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpphotoalbum`
--

CREATE TABLE `cpphotoalbum` (
  `id` int(10) NOT NULL,
  `vAlbum` varchar(100) DEFAULT '',
  `vPermalink` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpphotoalbum`
--

INSERT INTO `cpphotoalbum` (`id`, `vAlbum`, `vPermalink`) VALUES
(1, 'Test211AA', 'test211aa'),
(2, 'Toba', 'toba'),
(4, 'Test Album Photo', 'test-album-photo'),
(5, 'Kegiatan Rapat', 'kegiatan-rapat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpsession`
--

CREATE TABLE `cpsession` (
  `timestamp` int(15) NOT NULL DEFAULT '0',
  `vSignature` varchar(40) DEFAULT NULL,
  `vUsername` varchar(40) NOT NULL DEFAULT '',
  `iRemember` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cpusersonline`
--

CREATE TABLE `cpusersonline` (
  `timestamp` int(15) NOT NULL DEFAULT '0',
  `ip` varchar(40) NOT NULL DEFAULT '',
  `file` varchar(100) NOT NULL DEFAULT '',
  `idMember` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cpusersonline`
--

INSERT INTO `cpusersonline` (`timestamp`, `ip`, `file`, `idMember`) VALUES
(1670336651, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336651, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336650, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336498, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336497, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336472, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336472, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336320, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336321, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336322, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336322, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336649, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336612, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336650, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336472, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336471, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336471, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336448, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336448, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336448, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336448, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336409, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336374, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336375, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336407, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336408, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336409, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336409, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336063, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336499, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336499, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336319, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336446, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336373, '::1', '/tobakab/public/index.php/pages/hubungi-kami.html', 0),
(1670336374, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336374, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336065, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336066, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336066, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336067, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0),
(1670336614, '::1', '/tobakab/public/index.php/pages/vendors/jquery-ui/jquery-ui.min.js', 0),
(1670336499, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336615, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/i18n/datepicker.en.js', 0),
(1670336614, '::1', '/tobakab/public/index.php/pages/vendors/waypoints/jquery.waypoints.js', 0),
(1670336614, '::1', '/tobakab/public/index.php/pages/vendors/air-datepicker/js/datepicker.min.js', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `cpadmin`
--
ALTER TABLE `cpadmin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpapi`
--
ALTER TABLE `cpapi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpbanner`
--
ALTER TABLE `cpbanner`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpbannercategory`
--
ALTER TABLE `cpbannercategory`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpbantuan`
--
ALTER TABLE `cpbantuan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpbantuan_peserta`
--
ALTER TABLE `cpbantuan_peserta`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpcontent`
--
ALTER TABLE `cpcontent`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpcontentcategory`
--
ALTER TABLE `cpcontentcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpcontentcomment`
--
ALTER TABLE `cpcontentcomment`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpcontentmodule`
--
ALTER TABLE `cpcontentmodule`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpdoc`
--
ALTER TABLE `cpdoc`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpdoccategory`
--
ALTER TABLE `cpdoccategory`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpevent`
--
ALTER TABLE `cpevent`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpevent_peserta`
--
ALTER TABLE `cpevent_peserta`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpkehadiran`
--
ALTER TABLE `cpkehadiran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpkoperasi`
--
ALTER TABLE `cpkoperasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpkoperasi_detail`
--
ALTER TABLE `cpkoperasi_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cppage`
--
ALTER TABLE `cppage`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cppagecategory`
--
ALTER TABLE `cppagecategory`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cppageconf`
--
ALTER TABLE `cppageconf`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpphoto`
--
ALTER TABLE `cpphoto`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpphotoalbum`
--
ALTER TABLE `cpphotoalbum`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cpsession`
--
ALTER TABLE `cpsession`
  ADD KEY `timestamp` (`timestamp`),
  ADD KEY `vUsername` (`vUsername`),
  ADD KEY `iRemember` (`iRemember`),
  ADD KEY `vSignature` (`vSignature`);

--
-- Indeks untuk tabel `cpusersonline`
--
ALTER TABLE `cpusersonline`
  ADD KEY `timestamp` (`timestamp`),
  ADD KEY `ip` (`ip`),
  ADD KEY `file` (`file`),
  ADD KEY `idMember` (`idMember`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `cpadmin`
--
ALTER TABLE `cpadmin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `cpapi`
--
ALTER TABLE `cpapi`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `cpbanner`
--
ALTER TABLE `cpbanner`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `cpbannercategory`
--
ALTER TABLE `cpbannercategory`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `cpbantuan`
--
ALTER TABLE `cpbantuan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `cpbantuan_peserta`
--
ALTER TABLE `cpbantuan_peserta`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `cpcontent`
--
ALTER TABLE `cpcontent`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `cpcontentcategory`
--
ALTER TABLE `cpcontentcategory`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `cpcontentcomment`
--
ALTER TABLE `cpcontentcomment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `cpcontentmodule`
--
ALTER TABLE `cpcontentmodule`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;

--
-- AUTO_INCREMENT untuk tabel `cpdoc`
--
ALTER TABLE `cpdoc`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `cpdoccategory`
--
ALTER TABLE `cpdoccategory`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `cpevent`
--
ALTER TABLE `cpevent`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `cpevent_peserta`
--
ALTER TABLE `cpevent_peserta`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `cpkehadiran`
--
ALTER TABLE `cpkehadiran`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `cpkoperasi`
--
ALTER TABLE `cpkoperasi`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `cpkoperasi_detail`
--
ALTER TABLE `cpkoperasi_detail`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `cppage`
--
ALTER TABLE `cppage`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT untuk tabel `cppagecategory`
--
ALTER TABLE `cppagecategory`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `cppageconf`
--
ALTER TABLE `cppageconf`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT untuk tabel `cpphoto`
--
ALTER TABLE `cpphoto`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `cpphotoalbum`
--
ALTER TABLE `cpphotoalbum`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
